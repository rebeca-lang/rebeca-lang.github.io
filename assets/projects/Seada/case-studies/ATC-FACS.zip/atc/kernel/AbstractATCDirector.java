/* A director for modeling air traffic control systems.
 
 Copyright (c) 2015 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */
package ptolemy.domains.atc.kernel;

import java.util.Map;
import ptolemy.data.ArrayToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.actor.util.Time;
import ptolemy.domains.de.kernel.DEDirector;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

///////////////////////////////////////////////////////////////////
////ATCDirector
/** A director for modeling air traffic control systems.
 *  This director provides a receiver that consults the destination actor
 *  to determine whether it can accept an input, and provides mechanisms
 *  for handling rejection of an input.
 *  @author Maryam Bagheri.
 */
public abstract class AbstractATCDirector extends DEDirector {
    
    /** Create a new director in the specified container with the specified
     *  name.  The name must be unique within the container or an exception
     *  is thrown. The container argument must not be null, or a
     *  NullPointerException will be thrown.
     *
     *  @param container The container.
     *  @param name The name of this actor within the container.
     *  @exception IllegalActionException If this actor cannot be contained
     *   by the proposed container (see the setContainer() method).
     *  @exception NameDuplicationException If the name coincides with
     *   an entity already in the container.
     */
    
    public AbstractATCDirector(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        // TODO Auto-generated constructor stub
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         methods                    ////
    
    /** This function chooses an aircraft with the minimum fuel from a bunch of simultaneous aircrafts
     * that request to arrive in the destination track at a time.
     * If all aircraft have same fuel, it will choose one of them randomly.   
     * @param _id Id of the destination track.
     * @param currentTime The arrival time.
     * @return Id of the track which is owner of the chosen aircraft. -1 shows the next track has been occupied.
     * @throws IllegalActionException
     */
    public abstract int criticalRequestedPacket(Token _id, double currentTime) throws IllegalActionException;
    
    /** Return value of the _doPrediction variable.*/
    public abstract boolean is_doPrediction();
    
    /** Calculate the fuel consumption considering traveling time and speed of the aircraft.
     * @param timeOfTraveling Traveling time.
     * @param d Speed of the aircraft.
     * @return The amount of consumpted fuel.
     */
    public abstract double calculateFuelConsumption(double timeOfTraveling, double d);
    
    /**
     * 
     * @throws IllegalActionException
     */
    public abstract void clearATCDirector() throws IllegalActionException;
    
    /** This function finds configuration of the airspace and changes the value of _airspaceSituation.
     * 0 shows Airspace's normal situation, 1 shows airspace is congested,
     * 2 shows airspace is stormy and 3 shows airspace is stormy and congested.
     */
    public abstract void findAirspaceConfig() throws IllegalActionException;
    
    /** This function finds forbidden tracks placed in congestion regions. 
     *  If there exists any one, re-routing algorithm selects a path such that 
     *  the aircraft doesn�t move through the forbidden tracks.  
     * @throws IllegalActionException 
     */
    public abstract void findCongestionRegions() throws IllegalActionException;
    
    /**
     * Computed number of the blocked aircraft in the air.
     * @return
     * @throws IllegalActionException
     */
    public abstract int getNumberOfBlocked() throws IllegalActionException;

    /** Return an additional delay for a track to keep an aircraft in
     *  transit.
     *  @param trackForBacktracking
     *  @param rejector
     *  @return An additional delay, or -1.0 to indicate that a re-routing is possible.
     *  @throws IllegalActionException 
     */
    public abstract double handleRejectionWithDelay(Token id) throws IllegalActionException ;
    
    /**Update _stormyTracks array because of a change in condition of a track.
     * @param stormy Stormy condition of the track.
     * @param trackId Id of the track.
     * @throws IllegalActionException
     */
    public abstract void handleTrackAttributeChanged(Token stormy, Token trackId) throws IllegalActionException;

    /** Put an entry into _neighbors , _stormyTrack  and _inTransit for the initialized track.
     *  @param trackForBacktracking
     *  @throws IllegalActionException 
     */
    public abstract void handleInitializedTrack(Token trackId, Token stormy, ArrayToken neighbors) throws IllegalActionException;
    
    /** Handle initializing of an airport.
    *  @param airportForBackTracking
    *  @throws IllegalActionException 
    */
    public abstract void handleInitializedAirport(Token id) throws IllegalActionException;
   
   /** Handle initializing of a destination airport. 
    *  This function stores airport id in _airportsId 
    *  @param destinationAirportForBacktracking
    *  @throws IllegalActionException 
    */
    public abstract void handleInitializedDestination(Token id) throws IllegalActionException ;
   
   /** Set a color for the aircraft.
    * @param id Id of the aircraft.
    * @return color of the aircraft.
    * @throws IllegalActionException
    */
    public abstract ArrayToken handleAirplaneColor(int id) throws IllegalActionException;
  
    /** This algorithm finds the shortest path from the current track to the destination with no stormy track in it.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
    public abstract Map<String, Token> globallyLessCongestedShP(Token aircraft) throws IllegalActionException;
    
    /** Return id of the track (contains requesting aircraft) that has booked the intended track.
     * @param token Id of the intended track.
     * @return id or -1.
     */
    public abstract int getIdOfBookingTrack(Token token);
    
    /** An aircraft requests booking of the next place in 
     * (reachingTime - _predictionTime) that reachingTime is time of 
     * reaching the aircraft to the end of its current track.
     * @return Return value of the _predictionTime variable.
     */
    public abstract double getPredictionTime();
    
    public abstract boolean getPermission();
    
    /** This algorithm at first attempts to find the free shortest path (a path 
     * with no in transit aircraft and no storm) from the current track to the destination.
     * If it couldn't find, it tries to find the shortest path such it has not any forbidden track.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
    public abstract Map<String, Token> locallyLessCongestedShP(Token aircraft) throws IllegalActionException;  
    
    /** This function takes the results of the prediction and decides about the model (changes the re-routing algorithm).
     * After adapting model, it recovers  model to the time of change occurrence.
     * @param _count Number of the arrived aircraft to the destination actor.
     * @param aircraftNume Number of the aircraft have been planned to flight.  
     * @param _fDuration Accumulated flight duration of the arrived aircraft.
     * @param _dInAirport Accumulated delay in the source airport of the arrived aircraft.
     * @param _lastFlightTime Time of arriving last airplane to the destination airport.
     * @throws IllegalActionException 
     */
    public abstract void makeDecision(int _count, int _bInAir, int _bInAirport, int aircraftNume, double _fDuration,
            double _dInAirport, double _lastFlightTime) throws IllegalActionException;
    
    /** This algorithm at first attempts to find the free shortest path (a path 
     * with no in transit aircraft and no storm) from the current track to the destination.
     * If it couldn't find, it tries to find the shortest path.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
     public abstract Map<String, Token> normalSituationShP(Token aircraft) throws IllegalActionException;
    
     /** Update information of the _simultanouseAirpalne.
      * @param flight
      * @param priorTrack
      * @param nextTrack
      * @param fuel
      * @param _arriveInTime
      * @throws IllegalActionException
      */
     public abstract void updateInformation(Token flight, Token priorTrack, Token nextTrack,
          Double fuel, Time _arriveInTime) throws IllegalActionException;
     
    /** Routing an aircraft based on its flight map.
     * It finds the direction to the neighbor that its id is matched with the first element in aircraft's flight map.
     * After finding the direction, it updates aircraft's flight map by removing the first element.
     *  @param aircraft The aircraft is a record of "aircraftId","aircraftSpeed","flightMap" and "priorTrack" and ... .
     *  @param trackID
     *  @throws IllegalActionException 
     */
    public abstract RecordToken routing(Token aircraft, Token trackId) throws IllegalActionException;
    
    /** Return status of the track.
     *  @param trackId
     *  @throws IllegalActionException 
     */
    public abstract boolean returnTrackStatus(Token trackId);
      
    /** When an aircraft is rejected, ATCDirector switches to one of the re-routing algorithms 
     * based on the configuration of the airspace and reroutes the aircraft. 
     * @param aircraft
     * @return New flight map for the rejected aircraft.
     * @throws IllegalActionException
     */
    public abstract Map<String, Token> rerouteUnacceptedAircraft(Token aircraft) throws IllegalActionException;
    
    /** Remove booking for the track.
     * @param _id Id of the track.
     */
    public abstract void removeBooking(Token _id);
    
    /** This function return the amount of speed reduction.
     * When an aircraft arrives in the next track in while another aircraft is about to leave,
     * it have to decrease its speed.
     * @return
     */
    public abstract double reduceSpeed();
 
    /** Update inTransit status of a track.
     *  @param trackId
     *  @param reachingTim If there exist a moving aircraft in the track,
     *  then reachingTime shows time of reaching aircraft to the end of the track.
     *  Else it is -1.0.
     *  @throws IllegalActionException 
     */
    public abstract void setInTransitStatusOfTrack(Token trackId, double reachingTime) throws IllegalActionException;
    
    /** This function stores information of the aircraft at the start of its flight in a track.
     *  This information are used to find the simultaneous aircraft and 
     *  choosing one of them based on some policies. 
     * @param flightMap Aircraft's flight map.
     * @param priorTrack The current track of the aircraft. 
     * @param fuel The amount of the aircraft's fuel. 
     * @param _transitExpires Time of arriving the aircraft in the first of the destination track.
     * @throws IllegalActionException
     */
    public abstract void storeInformation(Token flightMap, Token priorTrack, double fuel, Time _transitExpires) 
            throws IllegalActionException;
   
    /** Each aircraft at the middle of its flight attempts to book the destination track for itself. 
     * So if the next track has not been booked, this function chooses one aircraft from a set of 
     * simultaneous aircraft and books the track for the chosen aircraft.
     * If that track has an in transit aircraft, it calculates the time distance between two flights 
     * and based on it, books the track for the aircraft or return unavailable (true).
     * @param token token Shows id of the track or destination airport.
     * @param _arriveInTime Time of arriving the aircraft at the first of the destination.
     * @param currentTrackOfAirplane
     * @return If next track is unavailable then return true.
     * @throws IllegalActionException
     */
    public abstract Map<String, Boolean> situationOfNextTrack(Token token, Time _arriveInTime, int currentTrackOfAirplane) throws IllegalActionException;
  
    /** If the airport has an in-transit aircraft, then set the leaving time of the aircraft.
     * @param _id
     * @param reachingTime
     */
    public abstract void setInTransitStatusOfAirport(Token _id, double reachingTime );

    public abstract int numberOfRerouting();

    
    
}
