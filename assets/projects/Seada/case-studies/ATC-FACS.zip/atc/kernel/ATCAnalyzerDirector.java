/* The ATCAnalyzer director is the higher level director in performance prediction.

 Copyright (c) 1998-2014 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY
 */
package ptolemy.domains.atc.kernel;

import java.util.List;
import ptolemy.actor.Actor;
import ptolemy.actor.util.Time;
import ptolemy.domains.de.kernel.DEDirector;
import ptolemy.domains.de.kernel.DEEvent;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

///////////////////////////////////////////////////////////////////
////ATCAnalyzerDirector
/**
 * ATCAnalyzerDirector is the higher level director in performance prediction. 
 * It will receive results of the prediction and will adapt the policies of the ATCDirector. 
 * It has a list of deferred events. 
 * These events are de-queued from first of the _eventQueue until a new generated event has been placed in the first of the _eventQueue. 
 * After prediction, deferred events are en-queued  again.
 * @author Maryam Bagheri.
 */

public class ATCAnalyzerDirector extends DEDirector{
    
    public ATCAnalyzerDirector(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        _init();
        // TODO Auto-generated constructor stub
    }

    /**
     * This function enqueues events from _eventQueue up to reaching a place that
     * the remaining events have less priority rather than the triggering event for the input parameter. 
     * @param actor
     * @throws IllegalActionException
     */
    public void enqueuePredictionEvent(Actor actor) throws IllegalActionException{
        int depth = _getDepthOfActor(actor);
        Time time=getModelTime();
        DEEvent newEvent= new DEEvent(actor,time,1,depth);
        
        synchronized(_eventQueue){
            if(_eventQueue.size()!=0){
                while(time.compareTo(_eventQueue.get().timeStamp())==0){
                    DEEvent firstEvent=_eventQueue.get();
                    if(firstEvent.microstep()>1 )
                    {
                        newEvent=new DEEvent(actor, time,firstEvent.microstep()-1,depth);
                        break;
                    }
                    else if(depth>firstEvent.depth())
                    {
                        _deferedEvents.add(_eventQueue.take());
                    }
                } 
            }
            _eventQueue.put(newEvent);
        }     
    }
    
    /** This function en-queue the difered events to the _eventQueue.
     * @throws IllegalActionException
     */
    public void enqueueDeferedEvents() throws IllegalActionException{
        
        synchronized(_eventQueue){
            while(_deferedEvents.size()!=0)
            {
                _eventQueue.put(_deferedEvents.remove(0));
            }
        }
    }
    ///////////////////////////////////////////////////////////////////
    ////                         private methods                 ////
    private void _init() {
        // TODO Auto-generated method stub
        _deferedEvents=null;
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         private variables                 ////
    private List<DEEvent> _deferedEvents=null;

}
