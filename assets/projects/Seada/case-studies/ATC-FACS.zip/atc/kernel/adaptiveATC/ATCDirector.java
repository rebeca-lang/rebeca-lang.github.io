/* A director for modeling air traffic control systems.
 
 Copyright (c) 2015 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */
package ptolemy.domains.atc.kernel.adaptiveATC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;

import ptolemy.actor.Receiver;
import ptolemy.domains.atc.kernel.ATCReceiver;
import ptolemy.domains.atc.kernel.AbstractATCDirector;
import ptolemy.domains.atc.kernel.DijkstraAlgorithm;
import ptolemy.data.ArrayToken;
import ptolemy.data.BooleanToken;
import ptolemy.data.DoubleToken;
import ptolemy.data.IntToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.data.type.BaseType;
import ptolemy.actor.util.Time;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

///////////////////////////////////////////////////////////////////
////ATCDirector
/** A director for modeling air traffic control systems.
 *  This director provides a receiver that consults the destination actor
 *  to determine whether it can accept an input, and provides mechanisms
 *  for handling rejection of an input.
 *  @author Maryam Bagheri.
 */
public class ATCDirector extends AbstractATCDirector {

    public ATCDirector(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        // TODO Auto-generated constructor stub
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         public methods                    ////

    @Override
    public Receiver newReceiver() {
        return new ATCReceiver();
    }
    
    /** This function chooses an aircraft with the minimum fuel from a bunch of simultaneous aircrafts
     * that request to arrive in the destination track at a time.
     * If all aircraft have same fuel, it will choose one of them randomly.   
     * @param _id Id of the destination track.
     * @param currentTime The arrival time.
     * @return Id of the track which is owner of the chosen aircraft. -1 shows the next track has been occupied.
     * @throws IllegalActionException
     */
    public int criticalRequestedPacket(Token _id, double currentTime) throws IllegalActionException {
        int id=-1;
        double minFuel=-1;
        RecordToken temp;
      // List of aircrafts request simultaneously.
        ArrayList<RecordToken> simultanous=new ArrayList<RecordToken>();
      // List of simultaneous aircrafts which have same minimum fuel.
        ArrayList<RecordToken> similar=new ArrayList<RecordToken>();
        if(_simultanousAirplanes==null)
            throw new IllegalActionException("There are no simultanous airplanes");
        for(int i=0;i<_simultanousAirplanes.size();i++)
        {
            temp=_simultanousAirplanes.get(i);
            if(temp.get("Track").equals(_id) && (((DoubleToken)temp.get("Time")).doubleValue())==currentTime){
                if(minFuel==-1){
                    similar.add(temp);
                    minFuel=((DoubleToken)temp.get("fuel")).doubleValue();
                  
                }
                else{
                    if(minFuel>((DoubleToken)temp.get("fuel")).doubleValue())
                    {
                        similar.clear();
                        similar.add(temp);
                        minFuel=((DoubleToken)temp.get("fuel")).doubleValue();
                      
                    }
                    else if(minFuel==((DoubleToken)temp.get("fuel")).doubleValue()){
                        similar.add(temp);
                    }
                }
                simultanous.add(temp);
            }
        }
        for(int i=0;i<simultanous.size();i++)
            if(_simultanousAirplanes.contains(simultanous.get(i)))
            {
                _simultanousAirplanes.remove(_simultanousAirplanes.indexOf(simultanous.get(i)));
            }
        Random randomGenerator=new Random();
        if(similar.size()>0)
        {
            int chooseNonDet=randomGenerator.nextInt(similar.size());
            id=((IntToken)similar.get(chooseNonDet).get("priorTrack")).intValue();
        }
        
        double x=0.0;
        int nextId=((IntToken)_id).intValue();
        // If id is id of a track.
        if(_inTransit.containsKey(nextId)) 
            // Track is occupied.
            if(_inTransit.get(nextId)!=(-1.0)) 
                x=_inTransit.get(nextId)-currentTime;
            else
                x=-1.0;
        // If id is id of a destination airport.
        else if(_inTransitAirport.containsKey(nextId))
            // Destination airport is occupied.
            if(_inTransitAirport.get(nextId)!= (-1.0)) 
                x=_inTransitAirport.get(nextId)-currentTime;
            else 
                x=-1.0;
        if(x>0)
            return -1;
       return id;
    }
    
    /** Calculate the fuel consumption considering traveling time and speed of the aircraft.
     * @param timeOfTraveling Traveling time.
     * @param d Speed of the aircraft.
     * @return The amount of consumpted fuel.
     */
    public double calculateFuelConsumption(double timeOfTraveling, double d) {
        // FIXME: what value should be returned here?
        return timeOfTraveling;
    }
    
    /**
     * 
     */
    public void clearATCDirector(){
       //Do nothing in this method. 
    }
    
    /** Return value of the _doPrediction variable.
     * There is not any variable named _doPrediction in this class and this function is not used.*/
    public boolean is_doPrediction() {
        return false;
    }
    
    /** This function finds configuration of the airspace and changes the value of _airspaceSituation.
     * 0 shows Airspace's normal situation, 1 shows airspace is congested,
     * 2 shows airspace is stormy and 3 shows airspace is stormy and congested.
     */
    public void findAirspaceConfig() throws IllegalActionException{
        
        boolean isStormy=false;
        findCongestionRegions();
        
        // Calculate number of the aircraft in the airspace.
        int num=0;
        for(Entry<Integer, Double> entry : _inTransit.entrySet()){
            if(entry.getValue()!=-1)
                num++;
            else if(_booked.containsValue(entry.getKey())){
                   // The aircraft is in  middle of its flight from prior track to the next track. 
                num++;
            }
        }
        
        int numberOfStormy=0;
        // Is there any stormy track?
        for (Entry<Integer, Token> entry : _stormyTracks.entrySet())
        {
            if(entry.getValue()==new BooleanToken(true))
            {
                isStormy=true;
                if(_inTransit.get(entry.getKey())==-1){ // Ignore common tracks between num and numberOfStormy.
                    numberOfStormy++;
                }
            }
        }
        
        // Globally congestion.
        if(_airspaceSituation==2 || _airspaceSituation==5){
            // Calculate number of aircraft in the airspace.
            
            if(num >(_numberOfAircrafts - (0.5 * _numberOfAircrafts)))
                return;
            else{
                // Return system to its initial load.
//                _decreaseLoad=false;
                _numberOfRerouting=0;
                _numberOfAircrafts=0;
            }
        }
        
        if(_numberOfRerouting>=_congestionIndex && num+numberOfStormy >(0.5)*_inTransit.size()){
            // Calculate number of the aircraft in meanwhile airspace is congested.
           _numberOfAircrafts=num;
           //********************************************
//           _decreaseLoad=true;
     
            if(isStormy)
                _airspaceSituation=5;
            else
                _airspaceSituation=2;
            return;
        }
        // There exists at least one locally congested area.
        if(_congestedTracks.size()!=0){
            if(isStormy)
                _airspaceSituation=4;
            else 
                _airspaceSituation=1;
            return;
        }
        
       if(isStormy)
           _airspaceSituation=3;
       else
           _airspaceSituation=0;
    }
    
    /** This function finds forbidden tracks placed in congestion regions. 
     *  If there exists any one, re-routing algorithm selects a path such that 
     *  the aircraft doesn�t move through the forbidden tracks.  
     * @throws IllegalActionException 
     */
    public void findCongestionRegions() throws IllegalActionException{
        _congestedTracks.clear();
        for(Entry<Integer, Double> entry : _inTransit.entrySet()){
            int id=entry.getKey();
            boolean isSelected=false;
            boolean northSelected=false;
            boolean southSelected=false;
            if(entry.getValue()!=-1 || (_booked.containsKey(id) && _booked.get(id)!=-1))
                isSelected=true;  // If this track has been booked or has a moving aircraft.
            ArrayToken neighbors=_neighbors.get(id);
            int count=0;
            for(int i=0;i<neighbors.length();i++)
            {
                int neighId=((IntToken)neighbors.getElement(i)).intValue();
                if(neighId==-1)
                    break;
                else if((_stormyTracks.containsKey(neighId) && _stormyTracks.get(neighId).equals(new BooleanToken(true))) || 
                        _inTransit.containsKey(neighId) && ((_inTransit.get(neighId)!=-1 && !_booked.containsValue(neighId)) || (_booked.containsKey(neighId) && _booked.get(neighId)!=-1)))
                    count++;
            }
            // Track has 3 moving aircrafts in its neighborhood.
            if(count==3){
                if(isSelected==true)
                    _congestedTracks.add(id);
               // North neighbor of the track.
                int neighId=((IntToken)neighbors.getElement(0)).intValue();
                ArrayToken neighNeigh=_neighbors.get(neighId);
                int k=0;
                for(int i=0;i<2;i++){
                    int j=((IntToken)neighNeigh.getElement(i)).intValue();
                    if(j!=-1 && ((_stormyTracks.containsKey(j) && _stormyTracks.get(j).equals(new BooleanToken(true))) || 
                            _inTransit.containsKey(j) && ((_inTransit.get(j)!=-1 && !_booked.containsValue(j)) || (_booked.containsKey(j)) && _booked.get(j)!=-1)))
                        k++;
                }
                if(k==2)
                {
                    northSelected=true;
                    _congestedTracks.add(neighId);
                }
               // South neighbor of the track.
                neighId=((IntToken)neighbors.getElement(2)).intValue();
                neighNeigh=_neighbors.get(neighId);
                k=0;
                for(int i=1;i<3;i++){
                    int j=((IntToken)neighNeigh.getElement(i)).intValue();
                    if(j!=-1 && (_stormyTracks.containsKey(j) && _stormyTracks.get(j).equals(new BooleanToken(true))) || 
                            _inTransit.containsKey(j) && ((_inTransit.get(j)!=-1 && !_booked.containsValue(j)) || (_booked.containsKey(j)) && _booked.get(j)!=-1))
                        k++;
                }
                if(k==2)
                {
                    southSelected=true;
                    _congestedTracks.add(neighId);
                }
                
                if(isSelected==false && northSelected==true && southSelected==true)
                {
                    // East neighbor of the track.
                    neighId=((IntToken)neighbors.getElement(1)).intValue();
                    neighNeigh=_neighbors.get(neighId);
                    int j=((IntToken)neighNeigh.getElement(1)).intValue();
                    if(j!=-1 && (_stormyTracks.containsKey(j) && _stormyTracks.get(j).equals(new BooleanToken(true))) || 
                            _inTransit.containsKey(j) && ((_inTransit.get(j)!=-1 && !_booked.containsValue(j)) || (_booked.containsKey(j)) && _booked.get(j)!=-1))
                        _congestedTracks.add(id);
                }
                    
            }
        }
    }

    /**
     * 
     */
    public int getNumberOfBlocked() throws IllegalActionException{
       // Do nothing in this method.
        return 0;
      }
    
    /** Return an additional delay for a track to keep an aircraft in
     *  transit.
     *  @param trackForBacktracking
     *  @param rejector
     *  @return An additional delay, or -1.0 to indicate that a re-routing is possible.
     *  @throws IllegalActionException 
     */
    public double handleRejectionWithDelay(Token id) throws IllegalActionException {
        // FIXME: what value should be returned here?
        return 1.0;
    }
    
    /**Update _stormyTracks array because of a change in condition of a track.
     * @param stormy Stormy condition of the track.
     * @param trackId Id of the track.
     * @throws IllegalActionException
     */
    public void handleTrackAttributeChanged(Token stormy, Token trackId) throws IllegalActionException {
        int id=((IntToken)trackId).intValue();
        if(_stormyTracks.size()!=0)
        {
            if(_stormyTracks.containsKey(id))
            {   
                _stormyTracks.put(id, stormy);
                // If it has been booked for an aircraft, and it is stormy, making it booking out. 
                if(((BooleanToken)stormy).booleanValue()==true)
                    if(_booked.containsKey(id))
                        _booked.put(id, -1);
            }
            else
                throw new IllegalActionException("The entry for this track has not been set in stormyTrack array."); 
        }
        
    }

    /** Put an entry into _neighbors , _stormyTrack  and _inTransit for the initialized track.
     *  @param trackForBacktracking
     *  @throws IllegalActionException 
     */
    public void handleInitializedTrack(Token trackId, Token stormy, ArrayToken neighbors) throws IllegalActionException{
        int id=((IntToken)trackId).intValue();
        if(id==-1)
            throw new IllegalActionException("Id of the track "+id+" is invalid (-1).");
        if(_stormyTracks.containsKey(id))
            throw new IllegalActionException("Track with the id "+id+" has been duplicated.");
        if(_airportsId.contains(id))
            throw new IllegalActionException("Track id is same as airport id.");
        else {
            if(stormy==null)
                throw new IllegalActionException("Stormy parameter of track "+id+" has not been filled.");
            
            _stormyTracks.put(id, (BooleanToken)stormy);
        }
        
        _inTransit.put(id,(-1.0));
        _neighbors.put(id, neighbors);
    }
    
    /** Handle initializing of an airport.
    *  @param airportForBackTracking
    *  @throws IllegalActionException 
    */
    public void handleInitializedAirport(Token id) throws IllegalActionException{
       int airportId=((IntToken)id).intValue();
       if(airportId==-1)
           throw new IllegalActionException("Invalid id for source airport.");
       if(_stormyTracks.containsKey(airportId))
           throw new IllegalActionException("Airport id is same as track id.");
       if(!_airportsId.contains(airportId))
           _airportsId.add(airportId);   
   }
   
   /** Handle initializing of a destination airport. 
    *  This function stores airport id in _airportsId 
    *  @param destinationAirportForBacktracking
    *  @throws IllegalActionException 
    */
    public void handleInitializedDestination(Token id) throws IllegalActionException {
       int airportId=((IntToken)id).intValue();
       if(airportId==-1)
           throw new IllegalActionException("Invalid id for destination airport");
       if(_airportsId.contains(airportId))
           throw new IllegalActionException("Duplication in airports id");
       if(_stormyTracks.containsKey(airportId))
           throw new IllegalActionException("Airport id is same as track id");
       _airportsId.add(airportId);
       _inTransitAirport.put(airportId,(-1.0));
       
   }
   
   /** Set a color for the aircraft.
    * @param id Id of the aircraft.
    * @return color of the aircraft.
    * @throws IllegalActionException
    */
    public ArrayToken handleAirplaneColor(int id) throws IllegalActionException{
       ArrayToken color = _airplanesColor.get(id);
       
       if (color == null) {
           Token[] colorSpec = new DoubleToken[4];
           colorSpec[0] = new DoubleToken(_random.nextDouble());
           colorSpec[1] = new DoubleToken(_random.nextDouble());
           colorSpec[2] = new DoubleToken(_random.nextDouble());
           colorSpec[3] = new DoubleToken(1.0);
           color = new ArrayToken(colorSpec);
           _airplanesColor.put(id, color);
       }
       
       return color;
   }
   
    @Override
    public void initialize() throws IllegalActionException {     
   // The _predictionTime can be changed here.
      _predictionTime=0.2;
      _numberOfRerouting=0;
      _airspaceSituation=0;
      _stormyTracks=new TreeMap<Integer, Token>();
      _booked=new TreeMap<Integer, Integer>();
      _neighbors=new TreeMap<Integer, ArrayToken>();
      _inTransit=new TreeMap<Integer, Double>();
      _inTransitAirport=new TreeMap<Integer, Double>();
      _airportsId= new ArrayList<Integer>();
      _simultanousAirplanes=new ArrayList<RecordToken>();
      _airplanesColor=new HashMap<Integer,ArrayToken>();
      _congestedTracks=new ArrayList<Integer>();
      _decreaseLoad=false;
      _numberOfAircrafts=0;
      super.initialize();
}
    
   
    /** This algorithm finds the shortest path from the current track to the destination with no stormy track in it.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
    public Map<String, Token> globallyLessCongestedShP(Token aircraft) throws IllegalActionException{
        
//        _decreaseLoad=true;
        
        RecordToken airplane=(RecordToken) aircraft;
        ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
        if(flightMap.length()==1){
            // It just contains id of the destination airport,it should send the airplane to that again.
            Map<String, Token> map=new TreeMap<String, Token>();
            map.put("flightMap", (Token)flightMap);
            map.put("route", new IntToken(-1));
            map.put("delay", new DoubleToken(1.0));
            return map;
        }
        int priorTrack=((IntToken)airplane.get("priorTrack")).intValue();
        boolean pathSelected=false;
        int route=-1;
        DijkstraAlgorithm x=new DijkstraAlgorithm();
        ArrayToken tempFlightMap=flightMap;
        Token[] shortestPath=null;
        for(int i=tempFlightMap.length()-1;i>=1;i--){
            int destination=((IntToken)tempFlightMap.getElement(i)).intValue();
            if(!_congestedTracks.isEmpty() && _congestedTracks.contains(destination))
                break;
            shortestPath=x.freeShortestPath(_neighbors, _airportsId, priorTrack, destination, _stormyTracks, _inTransit, _booked);
            if(shortestPath!=null){
                pathSelected=true;
                Token[] newPath=new Token[shortestPath.length-1+tempFlightMap.length()-i-1];
                int k=0;
                for(int j=1;j<shortestPath.length;j++)
                {
                    newPath[k++]=shortestPath[j];
                }
                
                if(i!=tempFlightMap.length()-1){
//                    break;
//                else{
                    tempFlightMap=tempFlightMap.subarray(i+1);
                    for(int j=0;j<tempFlightMap.length();j++)
                        newPath[k++]=tempFlightMap.getElement(j);
                }
                flightMap=new ArrayToken(BaseType.INT,newPath);
                break;
            }
                
        }
        
        if(pathSelected==false){
            shortestPath=x.lessCongestedDijkstra(_neighbors, _airportsId, priorTrack, ((IntToken)flightMap.getElement(flightMap.length()-1)).intValue(), _stormyTracks, _inTransit, _booked,_congestedTracks);
            if(shortestPath==null)
                shortestPath=x.callDijkstra(_neighbors, _airportsId,priorTrack, ((IntToken)flightMap.getElement(flightMap.length()-1)).intValue(), _stormyTracks, _inTransit,_booked);
            if(shortestPath!=null){
                pathSelected=true;
                Token[] newShortestPath=new Token[shortestPath.length-1];
                int j=0;
                for(int i=1;i<shortestPath.length;i++)
                {
                    newShortestPath[j++]=shortestPath[i];
                }
                flightMap=new ArrayToken(BaseType.INT, newShortestPath);
            }
        }
        
        if(pathSelected==true)
            for(int i=0;i<_neighbors.get(priorTrack).length();i++){
                if(_neighbors.get(priorTrack).getElement(i).equals(flightMap.getElement(0))){
                    route=i;
                    break;
                }
            }
        
       Map<String, Token> map=new TreeMap<String, Token>();
       map.put("flightMap", (Token)flightMap);
       map.put("route", new IntToken(route));
       map.put("delay", new DoubleToken(1.0));
       return map;
       
    }
    
    /** Return id of the track (contains requesting aircraft) that has booked the intended track.
     * @param token Id of the intended track.
     * @return id or -1.
     */
    public int getIdOfBookingTrack(Token token) {
        int id=((IntToken)token).intValue();
        if(_booked.containsKey(id))
            return _booked.get(id);
        return -1;
    }
    
    /** An aircraft requests booking of the next place in 
     * (reachingTime - _predictionTime) that reachingTime is time of 
     * reaching the aircraft to the end of its current track.
     * @return Return value of the _predictionTime variable.
     */
    public double getPredictionTime(){
        
        return _predictionTime;
    }
    
    public boolean getPermission() {
        // TODO Auto-generated method stub
        return _decreaseLoad;
    }
    
    /** This algorithm at first attempts to find the free shortest path (a path 
     * with no in transit aircraft and no storm) from the current track to the destination.
     * If it couldn't find, it tries to find the shortest path such it has not any forbidden track.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
    public Map<String, Token> locallyLessCongestedShP(Token aircraft) throws IllegalActionException{
        RecordToken airplane=(RecordToken) aircraft;
        ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
        if(flightMap.length()==1){
            // It just contains id of the destination airport,it should send the airplane to that again.
            Map<String, Token> map=new TreeMap<String, Token>();
            map.put("flightMap", (Token)flightMap);
            map.put("route", new IntToken(-1));
            map.put("delay", new DoubleToken(1.0));
            return map;
        }
         
        int priorTrack=((IntToken)airplane.get("priorTrack")).intValue(); // Current track of the aircraft.
        Token destination=flightMap.getElement(flightMap.length()-1);
        int route=-1;
        ArrayToken neighborsOfPriorTrack=_neighbors.get(priorTrack);      
        DijkstraAlgorithm x=new DijkstraAlgorithm();
        Token[] shortestPath=x.freeShortestPath(_neighbors, _airportsId,priorTrack, ((IntToken)destination).intValue(), _stormyTracks, _inTransit,_booked);
        if(shortestPath==null)
            shortestPath=x.lessCongestedDijkstra(_neighbors, _airportsId,priorTrack, ((IntToken)destination).intValue(), _stormyTracks, _inTransit,_booked,_congestedTracks);
        if(shortestPath==null)
            shortestPath=x.callDijkstra(_neighbors, _airportsId,priorTrack, ((IntToken)destination).intValue(), _stormyTracks, _inTransit,_booked);
        if(shortestPath!=null){
            Token[] newShortestPath=new Token[shortestPath.length-1];
            int j=0;
            for(int i=1;i<shortestPath.length;i++)
            {
                newShortestPath[j++]=shortestPath[i];
            }
            for(int i=0;i<neighborsOfPriorTrack.length();i++){
                if(neighborsOfPriorTrack.getElement(i).equals(newShortestPath[0])){
                    route=i;
                    break;
                }
            }
            
            flightMap=new ArrayToken(BaseType.INT, newShortestPath);
        }
           
       Map<String, Token> map=new TreeMap<String, Token>();
       map.put("flightMap", (Token)flightMap);
       map.put("route", new IntToken(route));
       map.put("delay", new DoubleToken(1.0));
       return map;
    }
    
    public void makeDecision(int _count, int _bInAir, int _bInAirport, int aircraftNume, double _fDuration,
            double _dInAirport, double _lastFlightTime)
            throws IllegalActionException {
        // TODO Auto-generated method stub
        // Do nothing in this method.
        
    }
    /** This algorithm at first attempts to find the free shortest path (a path 
     * with no in transit aircraft and no storm) from the current track to the destination.
     * If it couldn't find, it tries to find the shortest path.
     * @param aircraft
     * @return new flight map.
     * @throws IllegalActionException
     */
     public Map<String, Token> normalSituationShP(Token aircraft) throws IllegalActionException{
       RecordToken airplane=(RecordToken) aircraft;
       ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
       if(flightMap.length()==1){
           // It just contains id of the destination airport,it should send the airplane to that again.
           Map<String, Token> map=new TreeMap<String, Token>();
           map.put("flightMap", (Token)flightMap);
           map.put("route", new IntToken(-1));
           map.put("delay", new DoubleToken(1.0));
           return map;
       }
        
       int priorTrack=((IntToken)airplane.get("priorTrack")).intValue(); // Current track of the aircraft.
       Token destination=flightMap.getElement(flightMap.length()-1);
       int route=-1;
       ArrayToken neighborsOfPriorTrack=_neighbors.get(priorTrack);      
       DijkstraAlgorithm x=new DijkstraAlgorithm();
       Token[] shortestPath=x.freeShortestPath(_neighbors, _airportsId,priorTrack, ((IntToken)destination).intValue(), _stormyTracks, _inTransit,_booked);
       if(shortestPath==null)
           shortestPath=x.callDijkstra(_neighbors, _airportsId,priorTrack, ((IntToken)destination).intValue(), _stormyTracks, _inTransit,_booked);
       if(shortestPath!=null){
           Token[] newShortestPath=new Token[shortestPath.length-1];
           int j=0;
           for(int i=1;i<shortestPath.length;i++)
           {
               newShortestPath[j++]=shortestPath[i];
           }
           for(int i=0;i<neighborsOfPriorTrack.length();i++){
               if(neighborsOfPriorTrack.getElement(i).equals(newShortestPath[0])){
                   route=i;
                   break;
               }
           }
           
           flightMap=new ArrayToken(BaseType.INT, newShortestPath);
       }
          
      Map<String, Token> map=new TreeMap<String, Token>();
      map.put("flightMap", (Token)flightMap);
      map.put("route", new IntToken(route));
      map.put("delay", new DoubleToken(1.0));
      return map;
     }
    
     /** Update information of the _simultanouseAirpalne.
      * @param flight
      * @param priorTrack
      * @param nextTrack
      * @param fuel
      * @param _arriveInTime
      * @throws IllegalActionException
      */
     public void updateInformation(Token flight, Token priorTrack, Token nextTrack,
          Double fuel, Time _arriveInTime) throws IllegalActionException { 
         for(int i=0;i<_simultanousAirplanes.size();i++)
         {
             RecordToken r=_simultanousAirplanes.get(i);
             if(r.get("Track").equals(nextTrack) && r.get("priorTrack").equals(priorTrack))
             {
                 _simultanousAirplanes.remove(i);
                 break;
             }
         }
         
         Map<String, Token> packet=new TreeMap<String, Token>();
         packet.put("Track", ((ArrayToken)flight).getElement(0));
         packet.put("priorTrack", priorTrack);
         packet.put("fuel", (Token)(new DoubleToken(fuel)));
         packet.put("Time", (Token)(new DoubleToken(_arriveInTime.getDoubleValue())));
         _simultanousAirplanes.add(new RecordToken(packet));
         
     }
     
    /** Routing an aircraft based on its flight map.
     * It finds the direction to the neighbor that its id is matched with the first element in aircraft's flight map.
     * After finding the direction, it updates aircraft's flight map by removing the first element.
     *  @param aircraft The aircraft is a record of "aircraftId","aircraftSpeed","flightMap" and "priorTrack" and ... .
     *  @param trackID
     *  @throws IllegalActionException 
     */
    public RecordToken routing(Token aircraft, Token trackId) throws IllegalActionException{
        findAirspaceConfig();
        RecordToken airplane=(RecordToken) aircraft;
        ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
        int id=((IntToken)trackId).intValue();
        if(!flightMap.getElement(0).equals(trackId))
            throw new IllegalActionException("There is a mistake in routing: mismatch of track id "+id+" with first element in flight map "+((IntToken)flightMap.getElement(0)).intValue());
        Token nextTrackInFlight=flightMap.getElement(1);
        int route=-1;
        if(_neighbors.containsKey(id))
        {
            ArrayToken trackNeighbors=_neighbors.get(id);
            for(int i=0;i<trackNeighbors.length();i++)
                if(trackNeighbors.getElement(i).equals(nextTrackInFlight))
                {
                    route=i;
                    break;
                }
            if(route==-1)
                throw new IllegalActionException("Mistake in routing. track "+id+" has not neighbor track "+nextTrackInFlight);
        }else
            throw new IllegalActionException("Neighbors of the current track with id "+id+" have not been set.");
        
        Token [] newFlightMap=new Token[flightMap.length()-1];
        int j=0;
        for(int i=1;i<flightMap.length();i++)
            newFlightMap[j++]=flightMap.getElement(i);
        
        // Create a new aircraft record.
        Map<String, Token> newAirplane=new TreeMap<String, Token>();
        newAirplane.put("aircraftId", airplane.get("aircraftId"));
        newAirplane.put("aircraftSpeed", airplane.get("aircraftSpeed"));
        newAirplane.put("flightMap", (Token)(new ArrayToken(BaseType.INT, newFlightMap)));
        newAirplane.put("priorTrack", (Token)(new IntToken(id)));
        newAirplane.put("arrivalTimeToAirport", airplane.get("arrivalTimeToAirport"));
        newAirplane.put("dipartureTimeFromAirport", airplane.get("dipartureTimeFromAirport"));
        newAirplane.put("fuel", airplane.get("fuel"));
        
        // Add some information to newAirplane and then exploit and remove them from newAirplane 
        // (to transfer information to Track actor).
        newAirplane.put("delay", new DoubleToken(1.0));
        newAirplane.put("route", new IntToken(route));
        return (new RecordToken(newAirplane));
    }
    
    /** Return status of the track.
     *  @param trackId
     *  @throws IllegalActionException 
     */
    public boolean returnTrackStatus(Token trackId)  {
        int id=((IntToken)trackId).intValue();
        return ((_inTransit.get(id)!=(-1.0)) || ((BooleanToken)_stormyTracks.get(id)).booleanValue());
    }
      
    /** When an aircraft is rejected, ATCDirector switches to one of the re-routing algorithms 
     * based on the configuration of the airspace and reroutes the aircraft. 
     * @param aircraft
     * @return New flight map for the rejected aircraft.
     * @throws IllegalActionException
     */
    public Map<String, Token> rerouteUnacceptedAircraft(Token aircraft) throws IllegalActionException{
        findAirspaceConfig();
        Map<String, Token> map=new TreeMap<String, Token>();
//        switch(_airspaceSituation){
//        case 0:
//            map=normalSituationShP(aircraft);
//            break;
//        case 1:
//            map=locallyLessCongestedShP(aircraft);
//            break;
//        case 2:
            map=globallyLessCongestedShP(aircraft);
//            break;
//        case 3:
//            map=normalSituationShP(aircraft);
//            break;
//        case 4:
//            map=locallyLessCongestedShP(aircraft);
//            break;
//        case 5:
//            map=globallyLessCongestedShP(aircraft);
//            break;
//        }
        return map;
    }
    
    /** Remove booking for the track.
     * @param _id Id of the track.
     */
    public void removeBooking(Token _id) {
        int id=((IntToken)_id).intValue();
        for(int i=0 ; i<_booked.size();i++)
            if(_booked.containsKey(id))
                    _booked.put(id, -1);
    }
    
    /** This function return the amount of speed reduction.
     * When an aircraft arrives in the next track in while another aircraft is about to leave,
     * it have to decrease its speed.
     * @return
     */
    public double reduceSpeed() {
        // TODO Auto-generated method stub
        return 0.00001;
    }
 
    /** Update inTransit status of a track.
     *  @param trackId
     *  @param reachingTim If there exist a moving aircraft in the track,
     *  then reachingTime shows time of reaching aircraft to the end of the track.
     *  Else it is -1.0.
     *  @throws IllegalActionException 
     */
    public void setInTransitStatusOfTrack(Token trackId, double reachingTime) throws IllegalActionException{
        int id=((IntToken)trackId).intValue();
        if(_inTransit.containsKey(id)){
            _inTransit.put(id, reachingTime);     
        }
        else if(!_airportsId.contains(id))
            throw new IllegalActionException("There is no track with id "+id);
    }
    
    /** This function stores information of the aircraft at the start of its flight in a track.
     *  This information are used to find the simultaneous aircraft and 
     *  choosing one of them based on some policies. 
     * @param flightMap Aircraft's flight map.
     * @param priorTrack The current track of the aircraft. 
     * @param fuel The amount of the aircraft's fuel. 
     * @param _transitExpires Time of arriving the aircraft in the first of the destination track.
     * @throws IllegalActionException
     */
    public void storeInformation(Token flightMap, Token priorTrack, double fuel, Time _transitExpires) 
            throws IllegalActionException {
        ArrayToken map=(ArrayToken)flightMap;
        Token destinationTrack=(IntToken)map.getElement(0);
        
        Map<String, Token> packet=new TreeMap<String, Token>();
        packet.put("Track", destinationTrack);
        packet.put("priorTrack", priorTrack);
        packet.put("fuel", (Token)(new DoubleToken(fuel)));
        packet.put("Time", (Token)(new DoubleToken(_transitExpires.getDoubleValue())));
        
        _simultanousAirplanes.add(new RecordToken(packet));
        
    }
   
    /** Each aircraft at the middle of its flight attempts to book the destination track for itself. 
     * So if the next track has not been booked, this function chooses one aircraft from a set of 
     * simultaneous aircraft and books the track for the chosen aircraft.
     * If that track has an in transit aircraft, it calculates the time distance between two flights 
     * and based on it, books the track for the aircraft or return unavailable (true).
     * @param token token Shows id of the track or destination airport.
     * @param _arriveInTime Time of arriving the aircraft at the first of the destination.
     * @param currentTrackOfAirplane
     * @return If next track is unavailable then return true.
     * @throws IllegalActionException
     */
    public Map<String, Boolean> situationOfNextTrack(Token token, Time _arriveInTime, int currentTrackOfAirplane) throws IllegalActionException {
        Map<String, Boolean> map=new TreeMap<String, Boolean>();
        int id=((IntToken)token).intValue();
        
        double x=0.0;
     // If id is id of a track.
        if(_inTransit.containsKey(id)) 
            // Track is occupied.
            if(_inTransit.get(id)!=(-1.0)) 
                x=_inTransit.get(id)-_arriveInTime.getDoubleValue();
            else
                x=-1.0;
     // If id is id of a destination airport.
        else if(_inTransitAirport.containsKey(id))
            // Destination airport is occupied.
            if(_inTransitAirport.get(id)!= (-1.0)) 
                x=_inTransitAirport.get(id)-_arriveInTime.getDoubleValue();
            else 
                x=-1.0;
        
        // If (x>0) then unavailable=true.
        if(x==0.0)
            map.put("haveDelay", true);
        else if(x<0.0)
            map.put("haveDelay", false);
            
        if( _stormyTracks.containsKey(id) && ((BooleanToken)_stormyTracks.get(id)).booleanValue()==true )
        {   // Next track is stormy
            map.put("unAvailable", true);
            return map;
        }
        
        if(_booked.containsKey(id) && _booked.get(id)!=-1)
        { // Destination has been booked for one airplane.
                if(_booked.get(id)!=currentTrackOfAirplane)
                {   // Booked for another aircraft.
                    _numberOfRerouting++;
                    map.put("unAvailable", true);
                    return map;
                }
                else 
                {   // Booked for this aircraft.
                    map.put("unAvailable", false);
                    if(x>0)
                        throw new IllegalActionException("currentTrack "+currentTrackOfAirplane+" nexttrack "+id );
                    return map;
                }
                
        }
        else{
            // It has not been booked at all or at current time.
            int idOfAcceptedTrack=criticalRequestedPacket(token, _arriveInTime.getDoubleValue());
            
            if(idOfAcceptedTrack==-1)
            {   // Next place can not be booked.
                _numberOfRerouting++;
                map.put("unAvailable", true);
                return map;
            }
            
            _booked.put(id, idOfAcceptedTrack);
            
            if(idOfAcceptedTrack!=currentTrackOfAirplane)
            {
                _numberOfRerouting++;
                map.put("unAvailable", true);
                return map;
            }
            else
            {
                map.put("unAvailable", false);
                if(x>0)
                    throw new IllegalActionException("khar");
                return map;
            }
            
        }
       
    }
  
    /** If the airport has an in-transit aircraft, then set the leaving time of the aircraft.
     * @param _id
     * @param reachingTime
     */
    public void setInTransitStatusOfAirport(Token _id, double reachingTime ){
        int id=((IntToken)_id).intValue();
        _inTransitAirport.put(id, reachingTime);      
    }
    

    ///////////////////////////////////////////////////////////////////
    ////                         private variables                 ////
    
    /** This field stores airports id.*/
    private ArrayList<Integer> _airportsId= new ArrayList<Integer>();
    
    /** This field stores a color for each aircraft.*/
    private Map<Integer,ArrayToken> _airplanesColor = new HashMap<Integer,ArrayToken>();
    
    /** 0 shows Airspace's normal situation, 1 shows airspace is locally congested,
     * 2 shows airspace is globally congested, 3 shows airspace is stormy, 4 shows airspace is locally gensted and stormy
     *  and 5 shows airspace is globally congested and stormy. */
    private int _airspaceSituation;
    
    /** This field shows if the first element of the array (next track) is booked for the second element of the array (prior track id), else second
     * element is -1.
     */
    private Map<Integer, Integer> _booked=new TreeMap<Integer, Integer>();
    
    /** If number of rerouted aircrafts (_numberOfRerouting) is more than this value, congestion has occurred.*/
    private int _congestionIndex=40;
    
    /** This array stores forbidden tracks placed in the congestion regions. */
    private ArrayList<Integer> _congestedTracks;
    
    private boolean _decreaseLoad;
    
    /** This field stores existence of one aircraft in the track: first element is id and last is time of reaching aircraft to the end of the track.*/
    private Map<Integer, Double> _inTransit=new TreeMap<Integer, Double>();
    
    /** This field stores existence of one aircraft in the Destination Airport: first element is id and last is time of reaching aircraft to the end of the airport.*/
    private Map<Integer, Double> _inTransitAirport=new TreeMap<Integer, Double>();
    
    /**  This field stores neighbors of each track:first element is id of the track and last is array of its neighbors.*/
    private Map<Integer, ArrayToken> _neighbors=new TreeMap<Integer, ArrayToken>();
    
    /** This field counts number of re-routing if the destination track has been occupied. */
    private int _numberOfRerouting;
    
    /** number of aircraft at the time of global congestion occurrence. */
    private int _numberOfAircrafts;
    
    private double _predictionTime;
    
    private Random _random=new Random();
    
    /**  This field stores which track is stormy:first element is id of the track and last is a boolean token.*/
    private Map<Integer, Token> _stormyTracks=new TreeMap<Integer, Token>();
    
    /** All the requests of the aircrafts for arriving in their next places are stored in this field. */
    private ArrayList<RecordToken> _simultanousAirplanes=new ArrayList<RecordToken>();

    @Override
    public int numberOfRerouting() {
        // TODO Auto-generated method stub
        return 0;
    }

  
}
