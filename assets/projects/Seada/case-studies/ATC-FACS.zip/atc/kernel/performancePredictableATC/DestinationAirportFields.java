package ptolemy.domains.atc.kernel.performancePredictableATC;

import ptolemy.actor.util.Time;
import ptolemy.data.Token;
import ptolemy.vergil.kernel.attributes.ResizablePolygonAttribute;

public class DestinationAirportFields {
    public DestinationAirportFields(ResizablePolygonAttribute _shape,
            int _acceptedId, boolean _called, Token _inTransit,
            boolean _selectedAircraft, Time _transitExpires) {
        super();
        this._shape = _shape;
        this._acceptedId = _acceptedId;
        this._called = _called;
        this._inTransit = _inTransit;
        this._selectedAircraft = _selectedAircraft;
        this._transitExpires = _transitExpires;
    }
    
    public ResizablePolygonAttribute _shape;
    public int _acceptedId;
    public boolean _called;
    public Token _inTransit;
    public boolean _selectedAircraft;
    public Time _transitExpires;

}
