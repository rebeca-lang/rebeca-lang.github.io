package ptolemy.domains.atc.kernel.performancePredictableATC;

import java.util.ArrayList;

import ptolemy.actor.util.Time;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.kernel.util.IllegalActionException;

public class AirportFields {
    public AirportFields(ArrayList<RecordToken> _airplanes, Token _inTransit,
            Time _transitExpires) throws IllegalActionException {
        super();
        this._airplanes=new ArrayList<RecordToken>();
        for(int i=0;i<_airplanes.size();i++)
            this._airplanes.add(_airplanes.get(i));
        this._inTransit = _inTransit;
        this._transitExpires = _transitExpires;
    }
    public ArrayList<RecordToken> _airplanes;
    public Token _inTransit;
    public Time _transitExpires;
    
}
