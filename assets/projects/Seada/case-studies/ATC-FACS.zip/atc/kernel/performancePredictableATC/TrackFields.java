package ptolemy.domains.atc.kernel.performancePredictableATC;

import ptolemy.actor.util.Time;
import ptolemy.data.Token;
import ptolemy.vergil.kernel.attributes.EllipseAttribute;
import ptolemy.vergil.kernel.attributes.ResizablePolygonAttribute;

public class TrackFields {
    
    public TrackFields(ResizablePolygonAttribute _shape,
            EllipseAttribute _circle, Time _arriveInTime, int _acceptedId,
            int _counter, boolean _called, double _delayOfEachAirplanes,
            Token _inTransit, Token _isStormy,
            boolean _selectedAircraft, int _OutRoute, Time _transitExpires) {
        super();
        this._shape = _shape;
        this._circle = _circle;
        this._arriveInTime = _arriveInTime;
        this._acceptedId = _acceptedId;
        this._counter = _counter;
        this._called = _called;
        this._delayOfEachAirplanes = _delayOfEachAirplanes;
        this._inTransit = _inTransit;
        this._isStormy = _isStormy;
        this._selectedAircraft = _selectedAircraft;
        this._OutRoute = _OutRoute;
        this._transitExpires = _transitExpires;
    }
    
    public ResizablePolygonAttribute _shape;
    public EllipseAttribute _circle;
    public Time _arriveInTime;
    public int _acceptedId;
    public int _counter;
    public boolean _called;
    public double _delayOfEachAirplanes;
    public Token _inTransit;
    public Token _isStormy;
    public boolean _selectedAircraft;
    public int _OutRoute;
    public Time _transitExpires;
}
