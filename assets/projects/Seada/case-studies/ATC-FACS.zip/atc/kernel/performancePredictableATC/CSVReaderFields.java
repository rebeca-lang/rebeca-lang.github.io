package ptolemy.domains.atc.kernel.performancePredictableATC;

public class CSVReaderFields {

    public CSVReaderFields(String _currentLine, String _nextLine) {
        super();
        this._currentLine = _currentLine;
        this._nextLine = _nextLine;
    }
    public String _currentLine;
    public String _nextLine;

}
