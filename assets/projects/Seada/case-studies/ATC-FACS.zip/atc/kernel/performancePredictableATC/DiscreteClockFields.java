package ptolemy.domains.atc.kernel.performancePredictableATC;

import ptolemy.actor.util.Time;

public class DiscreteClockFields {
    
    
    public DiscreteClockFields(int _cycleCount, Time _cycleStartTime,
            boolean _enabled, boolean _firstOutputProduced,
            Time _nextOutputTime, int _nextOutputIndex, int _phase) {
        super();
        this._cycleCount = _cycleCount;
        this._cycleStartTime = _cycleStartTime;
        this._enabled = _enabled;
        this._firstOutputProduced = _firstOutputProduced;
        this._nextOutputTime = _nextOutputTime;
        this._nextOutputIndex = _nextOutputIndex;
        this._phase = _phase;
    }
    
    public int _cycleCount;
    public Time _cycleStartTime;
    public boolean _enabled;
    public  boolean _firstOutputProduced;
    public Time _nextOutputTime;
    public int _nextOutputIndex;
    public transient int _phase;

}
