/* A model of an actor to calculated performance measures in air traffic control systems.
 
 Copyright (c) 2015 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */
package ptolemy.domains.atc.lib;


import java.util.Map;
import java.util.TreeMap;

import ptolemy.actor.Director;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;
import ptolemy.actor.util.Time;
import ptolemy.data.DoubleToken;
import ptolemy.data.IntToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.ArrayType;
import ptolemy.data.type.BaseType;
import ptolemy.data.type.RecordType;
import ptolemy.data.type.Type;
import ptolemy.domains.atc.kernel.AbstractATCDirector;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Attribute;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;
///////////////////////////////////////////////////////////////////
////InfoWriter
/** This actor is used to calculate performance parameters (such as number of the blocked aircraft in the air) and send them out.
 *  @author Maryam Bagheri.
 */
public class InfoWriter extends TypedAtomicActor{

    public InfoWriter(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        
        input = new TypedIOPort(this, "input", true, false);
        input.setMultiport(true);
        input.setTypeEquals(new RecordType(_lables, _types));
        
        output = new TypedIOPort(this, "Output", false, true);
        output.setTypeEquals(BaseType.RECORD); 
        
        delay= new Parameter(this, "modelExecutionTime");
        delay.setTypeEquals(BaseType.DOUBLE);
       
        
        aircraftNum=new Parameter(this, "aircraftNumber");
        aircraftNum.setTypeEquals(BaseType.INT);
        aircraftNum.setExpression("100");    
        
        iterationId=new Parameter(this, "iterationId");
        iterationId.setTypeEquals(BaseType.INT);
        iterationId.setExpression("-1");
        
    }
    ///////////////////////////////////////////////////////////////////
    ////                       ports and parameters                //// 
    public TypedIOPort input, output;
    public Parameter delay, aircraftNum, iterationId;
    
    ///////////////////////////////////////////////////////////////////
    ////                         public methods                    ////
    
    @Override
    public void attributeChanged(Attribute attribute) throws IllegalActionException {
        if(attribute==iterationId)
            _itID=iterationId.getToken();
    }
    
    @Override
    public void fire() throws IllegalActionException {
        super.fire();
        Time currentTime=_director.getModelTime();
        if(currentTime.equals(_transitExpires)){
            _bInAir=((AbstractATCDirector)_director).getNumberOfBlocked();
            _bInAirport=((IntToken)aircraftNum.getToken()).intValue()-_bInAir-_count;
            ((AbstractATCDirector)_director).clearATCDirector();  
            Map<String, Token> info=new TreeMap<String, Token>();
//            info.put("NumberOfStorm", new IntToken(_numberOfStorm));
            info.put("NOfArrived",new IntToken(_count));
            info.put("BlockedInAir", new IntToken(_bInAir));
            info.put("BlockedInAirport", new IntToken(_bInAirport));
            info.put("AverageFlightD", new DoubleToken(_fDuration/_count));
            info.put("AverageDelayInAirport", new DoubleToken(_dInAirport/_count));
            info.put("TimeOfLastA", new DoubleToken(_lastFlightTime));
            info.put("iterationId", _itID);
            Token param=(Token) new RecordToken(info);
            output.send(0, param);
           return;
        }
        for(int i=0; i< input.getWidth();i++){
            if(input.hasNewToken(i)){
               _count++;
               RecordToken airplane=(RecordToken)input.get(i);
               _fDuration+=currentTime.getDoubleValue()-((DoubleToken)airplane.get("dipartureTimeFromAirport")).doubleValue();
               _dInAirport+=((DoubleToken)airplane.get("dipartureTimeFromAirport")).doubleValue()-((DoubleToken)airplane.get("arrivalTimeToAirport")).doubleValue();
               _lastFlightTime=currentTime.getDoubleValue();
               _numberOfStorm=((AbstractATCDirector)_director).numberOfRerouting();
            }
        }
    }
    
    @Override
    public void initialize() throws IllegalActionException {
        super.initialize();
        _count=0;
        if(delay.getToken()==null || ((DoubleToken)delay.getToken()).doubleValue()==0.0)
            throw new IllegalActionException(" The model execution time can not be null or zero");
        
        _director=getDirector();
        _transitExpires=_director.getModelTime().add(((DoubleToken)delay.getToken()).doubleValue());
        _director.fireAt(this, _transitExpires);
        _fDuration=0.0;
        _dInAirport=0.0;
        _lastFlightTime=0.0;
        _bInAir=0;
        _bInAirport=0;
        _itID=iterationId.getToken();
        _numberOfStorm=0;
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         private variables               ////
    private int _bInAirport;
    private Token _itID;
    private int _bInAir;
    private int _count;
    private Director _director;
    private double _fDuration;
    private double _dInAirport;
    private double _lastFlightTime;
    private String[] _lables={"aircraftId","aircraftSpeed","flightMap","priorTrack","fuel","arrivalTimeToAirport","dipartureTimeFromAirport"};
    private Type[] _types={BaseType.INT,BaseType.DOUBLE,new ArrayType(BaseType.INT),BaseType.INT,BaseType.DOUBLE,BaseType.DOUBLE,BaseType.DOUBLE};
    private Time _transitExpires;
    private int _numberOfStorm;

    
}
