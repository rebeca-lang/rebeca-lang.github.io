/* A model of a track in air traffic control systems.
 
 Copyright (c) 2015 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */
package ptolemy.domains.atc.lib;


import java.util.Map;
import java.util.TreeMap;



import ptolemy.actor.Director;
import ptolemy.actor.IOPort;
import ptolemy.actor.NoRoomException;
import ptolemy.actor.TypedIOPort;
import ptolemy.actor.util.Time;
import ptolemy.data.ArrayToken;
import ptolemy.data.BooleanToken;
import ptolemy.data.DoubleToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.data.IntToken;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.ArrayType;
import ptolemy.data.type.BaseType;
import ptolemy.data.type.RecordType;
import ptolemy.domains.atc.kernel.AbstractATCDirector;
import ptolemy.domains.atc.kernel.Rejecting;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Attribute;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;
import ptolemy.kernel.util.StringAttribute;
import ptolemy.vergil.icon.EditorIcon;
import ptolemy.vergil.kernel.attributes.EllipseAttribute;
import ptolemy.vergil.kernel.attributes.ResizablePolygonAttribute;
import ptolemy.data.type.Type;

///////////////////////////////////////////////////////////////////
////Track
/** A model of a track in air traffic control systems.
 *  This track can have no more than one aircraft in transit.
 *  If there is one in transit, then it rejects all inputs.
 *  @author Maryam Bagheri.
 */
public class Track extends  TrackWriter implements Rejecting {

    public Track(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        
        
        input = new TypedIOPort(this, "input", true, false);
        input.setMultiport(true);
                
        northOutput = new TypedIOPort(this, "northOutput", false, true);
        northOutput.setTypeEquals(new RecordType(_lables, _types));
        StringAttribute cardinality = new StringAttribute(northOutput, "_cardinal");
        cardinality.setExpression("NORTH");
                

        eastOutput=new TypedIOPort(this, "eastOutput", false, true); 
        eastOutput.setTypeEquals(new RecordType(_lables, _types));
        cardinality = new StringAttribute(eastOutput, "_cardinal");
        cardinality.setExpression("EAST");
        
                
        southOutput = new TypedIOPort(this, "southOutput", false, true);
        southOutput.setTypeEquals(new RecordType(_lables, _types));
        cardinality = new StringAttribute(southOutput, "_cardinal");
        cardinality.setExpression("SOUTH");
    
        
        trackId= new Parameter(this, "trackId");
        trackId.setTypeEquals(BaseType.INT);
        trackId.setExpression("-1");
        
        neighbors = new Parameter(this, "neighbors{North,East,South");
        neighbors.setExpression("{-1,-1,-1}");
        neighbors.setTypeEquals(new ArrayType(BaseType.INT));
        
        stormy=new Parameter(this, "stormy");
        stormy.setTypeEquals(BaseType.BOOLEAN);
        _attachText("_iconDescription", "<svg> <path d=\"M 194.67321,2.8421709e-14 L 70.641958,53.625 "
                + "C 60.259688,46.70393 36.441378,32.34961 31.736508,30.17602 C -7.7035221,11.95523 "
                + "-5.2088921,44.90709 11.387258,54.78122 C 15.926428,57.48187 39.110778,71.95945 "
                + "54.860708,81.15624 L 72.766958,215.09374 L 94.985708,228.24999 L 106.51696,107.31249 "
                + "L 178.04821,143.99999 L 181.89196,183.21874 L 196.42321,191.84374 L 207.51696,149.43749 "
                + "L 207.64196,149.49999 L 238.45446,117.96874 L 223.57946,109.96874 L 187.95446,126.87499 "
                + "L 119.67321,84.43749 L 217.36071,12.25 L 194.67321,2.8421709e-14 z\" "
                + "style=\"fill:#000000;fill-opacity:1;fill-rule:evenodd;stroke:none;stroke-width:1px;stroke-linecap:butt;"
                + "stroke-linejoin:miter;stroke-opacity:1\" id=\"path5724\"/></svg>");

        // Create an icon for this node.
        EditorIcon node_icon = new EditorIcon(this, "_icon");
        
        _circle = new EllipseAttribute(node_icon, "_circleShap");
        _circle.centered.setToken("true");
        _circle.width.setToken("40");
        _circle.height.setToken("40");
        _circle.fillColor.setToken("{0.0, 0.0, 0.0, 0.0}");
        _circle.lineColor.setToken("{0.0, 0.0, 0.0, 0.0}");

        _shape = new ResizablePolygonAttribute(node_icon, "_trackShape");
        _shape.centered.setToken("true");
        _shape.width.setToken("40");
        _shape.height.setToken("40");
        _shape.vertices.setExpression("{-194.67321,2.8421709e-14, -70.641958,53.625, "
                + "-60.259688,46.70393, -36.441378,32.34961, -31.736508,30.17602, 7.7035221,11.95523, "
                + "5.2088921,44.90709,-11.387258,54.78122,-15.926428,57.48187,-39.110778,71.95945, "
                + "-54.860708,81.15624,-72.766958,215.09374,-94.985708,228.24999,-106.51696,107.31249, "
                + "-178.04821,143.99999,-181.89196,183.21874,-196.42321,191.84374,-207.51696,149.43749, "
                + "-207.64196,149.49999,-238.45446,117.96874,-223.57946,109.96874,-187.95446,126.87499, "
                + "-119.67321,84.43749,-217.36071,12.25,-194.67321,2.8421709e-14}");
        _shape.fillColor.setToken("{1.0, 1.0, 1.0, 1.0}");
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                       ports and parameters                ////

    public TypedIOPort input;
    public TypedIOPort northOutput, eastOutput, southOutput;
    public Parameter trackId, neighbors, stormy;
    
    ///////////////////////////////////////////////////////////////////
    ////                         public methods                    ////
    
    @Override
    public boolean reject(Token token, IOPort port) throws IllegalActionException {
        RecordToken requester=(RecordToken)token;
        boolean unAvailable=(_inTransit != null || ((BooleanToken)_isStormy).booleanValue());
        if(unAvailable==true){
            return true;
        }
        
        if(_selectedAircraft==false){
            if(_called==false){
                /* AcceptedId is -1 for the source airport. So for multiple requests from several airports just select the first one.
                 * But if an airport and a track or several tracks request, tracks have higher priority.
                 * If several tracks request, priority is by the one with less fuel.
                 * If all have same fuel, one of them is chosen randomly.
                 */
                _called=true;
                _acceptedId=((AbstractATCDirector)_director).getIdOfBookingTrack(_id);
                if(_acceptedId==-1 || _acceptedId==((IntToken)requester.get("priorTrack")).intValue())
                {
                    _selectedAircraft=true;
                    return false;
                }
            }
            
            if(_acceptedId==((IntToken)requester.get("priorTrack")).intValue()){
                _selectedAircraft=true;
                return false;
            }
        }
        return true;
    }
    
    @Override
    public void attributeChanged(Attribute attribute) throws IllegalActionException {
        Director director=getDirector();
        if(trackId.getToken()!=null)
            _id=trackId.getToken();
        if (attribute == stormy) {
             if(stormy.getToken()!=null){
                _isStormy=stormy.getToken();
                
                //Change color of the storm zone
                if(((BooleanToken)_isStormy).booleanValue()==true)
                    _circle.fillColor.setToken("{1.0,0.2,0.2,1.0}");
                else
                    _circle.fillColor.setToken("{0.0, 0.0, 0.0, 0.0}");
                //
                
                ((AbstractATCDirector)director).handleTrackAttributeChanged(_isStormy,_id);
            }
        }
        else {
            super.attributeChanged(attribute);
        }
    }
    
    @Override
    public void declareDelayDependency() throws IllegalActionException {
     _declareDelayDependency(input, northOutput, 0.0);
     _declareDelayDependency(input, eastOutput, 0.0);
     _declareDelayDependency(input, southOutput, 0.0);         
 }
    
    @Override
    public void fire() throws IllegalActionException {
        super.fire();
        Time currentTime = _director.getModelTime();
        int trackId= ((IntToken)_id).intValue();
        Token nextTrack=null;
        if(_OutRoute!=-1)
            nextTrack=((ArrayToken)neighbors.getToken()).getElement(_OutRoute);
        
        // At middle of the flight.
        if(currentTime.equals(_transitExpires) && _inTransit != null) {
            // Before reaching to the next track, call director to know about the situation of the next track.
            Map<String, Boolean> availability=((AbstractATCDirector)_director).situationOfNextTrack(nextTrack,_arriveInTime,trackId);
            boolean unAvailable=availability.get("unAvailable");
//            if(((AbstractATCDirector)_director).isTest())
//                throw new IllegalActionException("hey "+unAvailable);
            if(unAvailable==true)
            {
                //Next Track is stormy or has been occupied or booked / or is booked for another airplane.
                // Reroute
                
                Map<String, Token> temp=new TreeMap<String, Token>();
                double additionalDelay=0.0;
                temp=((AbstractATCDirector)_director).rerouteUnacceptedAircraft(_inTransit);
                if(((IntToken)temp.get("route")).intValue()==-1)
                { // Stay in current track.
                    additionalDelay = ((AbstractATCDirector)_director).handleRejectionWithDelay(_id);
                    if (additionalDelay < 0.0) {
                        throw new IllegalActionException(this, "Unable to handle rejection.");
                    }
                    //Change delay.
                    _delayOfEachAirplanes+=additionalDelay-((AbstractATCDirector)_director).getPredictionTime();
                }
                else
                {// Send airplane through another route.
                    Map<String, Token> newAircraft=new TreeMap<String, Token>();
                    newAircraft.put("aircraftId",( (RecordToken)_inTransit).get("aircraftId"));
                    newAircraft.put("aircraftSpeed", ((RecordToken)_inTransit).get("aircraftSpeed"));
                    newAircraft.put("flightMap", (Token)temp.get("flightMap"));
                    newAircraft.put("priorTrack", ((RecordToken)_inTransit).get("priorTrack"));
                    newAircraft.put("fuel",((RecordToken)_inTransit).get("fuel"));
                    newAircraft.put("arrivalTimeToAirport", ((RecordToken)_inTransit).get("arrivalTimeToAirport"));
                    newAircraft.put("dipartureTimeFromAirport", ((RecordToken)_inTransit).get("dipartureTimeFromAirport"));
                    Token transmitedAircraft=(Token) new RecordToken(newAircraft);
                    _inTransit=transmitedAircraft;
                    
                    additionalDelay=((DoubleToken)temp.get("delay")).doubleValue();
                    _delayOfEachAirplanes+=((DoubleToken)temp.get("delay")).doubleValue()-((AbstractATCDirector)_director).getPredictionTime();
                    _OutRoute=((IntToken)temp.get("route")).intValue();
                    
                } //End of else.
               
                _arriveInTime=currentTime.add(additionalDelay); 
                _transitExpires=currentTime.add(additionalDelay-((AbstractATCDirector)_director).getPredictionTime());
                _inTransit=_changingFuel(_inTransit,additionalDelay-((AbstractATCDirector)_director).getPredictionTime());
                Double fuel=((DoubleToken)((RecordToken)_inTransit).get("fuel")).doubleValue();
                // As the route of the aircraft has been changed, store request of the aircraft for the new found track.
                // To solve backtracking error.
                Token f=temp.get("flightMap");
                Token p=((RecordToken)_inTransit).get("priorTrack");
                ((AbstractATCDirector)_director).updateInformation(f,p,nextTrack,fuel, _arriveInTime);
                // Aircraft will leave this track at new time.
                ((AbstractATCDirector)_director).setInTransitStatusOfTrack(_id, _arriveInTime.getDoubleValue());
                _director.fireAt(this, _transitExpires);
                
                 
            } // End of if(unAvailable==true).
            else{
                    // Next Track has been booked for this airplane.
                    // Change fuel and delay of the airplane.
                    _inTransit=_changingFuel(_inTransit,((AbstractATCDirector)_director).getPredictionTime());
                    _delayOfEachAirplanes+=((AbstractATCDirector)_director).getPredictionTime();
                    /* If the current aircraft reaches to the new track at the same time that new track's aircraft leaves,
                    * reduce speed of the current aircraft.
                    */
                   if(availability.get("haveDelay")==true)
                   {
                       _arriveInTime= _arriveInTime.add(((AbstractATCDirector)_director).reduceSpeed());
                    // Aircraft will leave this track at new time.
                       ((AbstractATCDirector)_director).setInTransitStatusOfTrack(_id, _arriveInTime.getDoubleValue());
                   }
                    _director.fireAt(this, _arriveInTime); 
            }
           return;
        }
        
        // At this time, aircraft is about to leave the current track.
        if (currentTime.equals(_arriveInTime) && _inTransit != null) {
            // Write to file.
            _valuesForFile[2]=new DoubleToken(currentTime.getDoubleValue());
            _valuesForFile[4]=new DoubleToken(_delayOfEachAirplanes);
            _writeToFile=new RecordToken(_lablesOfFile,_valuesForFile);
//            _writingToFile((Token)_writeToFile);
//            // End of writing to file.
            try{
                if(_OutRoute==0){
                    northOutput.send(0, _inTransit);
                }else if(_OutRoute==1){
                    eastOutput.send(0, _inTransit);
                }else{
                    southOutput.send(0, _inTransit);
                }
                _setIcon(-1);
            }
            catch (NoRoomException ex){
             // Token rejected by the destination.
             // Remove booking for the next track.
                if(((AbstractATCDirector)_director).getIdOfBookingTrack(nextTrack)==trackId)
                    ((AbstractATCDirector)_director).removeBooking(nextTrack);
                if (!(_director instanceof AbstractATCDirector)) {
                    throw new IllegalActionException(this, "Track must be used with an ATCDirector.");
                }
                Map<String, Token> temp=new TreeMap<String, Token>();
                double additionalDelay=0.0;
                temp=((AbstractATCDirector)_director).rerouteUnacceptedAircraft(_inTransit);
                if(((IntToken)temp.get("route")).intValue()==-1)
                { // Stay in current track.
                    additionalDelay = ((AbstractATCDirector)_director).handleRejectionWithDelay(_id);
                    if (additionalDelay < 0.0) {
                        throw new IllegalActionException(this, "Unable to handle rejection.");
                    }
                    // Change delay.
                    _delayOfEachAirplanes+=additionalDelay-((AbstractATCDirector)_director).getPredictionTime();;
                }
                else
                {// Send airplane through another route.
                    Map<String, Token> newAircraft=new TreeMap<String, Token>();
                    newAircraft.put("aircraftId",( (RecordToken)_inTransit).get("aircraftId"));
                    newAircraft.put("aircraftSpeed", ((RecordToken)_inTransit).get("aircraftSpeed"));
                    newAircraft.put("flightMap", (Token)temp.get("flightMap"));
                    newAircraft.put("priorTrack", ((RecordToken)_inTransit).get("priorTrack"));
                    newAircraft.put("fuel",((RecordToken)_inTransit).get("fuel"));
                    newAircraft.put("arrivalTimeToAirport", ((RecordToken)_inTransit).get("arrivalTimeToAirport"));
                    newAircraft.put("dipartureTimeFromAirport", ((RecordToken)_inTransit).get("dipartureTimeFromAirport"));
                    Token transmitedAircraft=(Token) new RecordToken(newAircraft);
                    _inTransit=transmitedAircraft;
                    additionalDelay=((DoubleToken)temp.get("delay")).doubleValue();
                    _delayOfEachAirplanes+=((DoubleToken)temp.get("delay")).doubleValue()-((AbstractATCDirector)_director).getPredictionTime();;
                    _OutRoute=((IntToken)temp.get("route")).intValue();
                    
                } // End of else.
                
                _arriveInTime=currentTime.add(additionalDelay);
                _transitExpires=currentTime.add(additionalDelay-((AbstractATCDirector)_director).getPredictionTime());
                _inTransit=_changingFuel(_inTransit,additionalDelay-((AbstractATCDirector)_director).getPredictionTime());
                Double fuel=((DoubleToken)((RecordToken)_inTransit).get("fuel")).doubleValue();
                Token f=temp.get("flightMap");
                Token p=((RecordToken)_inTransit).get("priorTrack");
                ((AbstractATCDirector)_director).updateInformation(f,p,nextTrack,fuel, _arriveInTime);
                ((AbstractATCDirector)_director).setInTransitStatusOfTrack(_id, _arriveInTime.getDoubleValue());
                _director.fireAt(this, _transitExpires);
               return; 
            } // End of catch.
            
            // Token has been sent successfully.
            _inTransit = null;
            _called=false;
            _acceptedId=-1;
            _selectedAircraft=false;
            ((AbstractATCDirector)_director).setInTransitStatusOfTrack(_id, -1.0);
            //I am free but next track is becoming busy.
//            ((ATCDirector)_director).setInTransitStatusOfTrackForRerout(_id, false);
//            ((ATCDirector)_director).setInTransitStatusOfTrackForRerout(((ArrayToken)neighbors.getToken()).getElement(_OutRoute), true);
        
        } // End of if (currentTime.equals(_arriveInTime) && _inTransit != null).
        
        
        // Handle any input that have been accepted.
        for(int i=0;i<input.getWidth();i++)
            if(input.hasNewToken(i))
            {
                // This if is for chacking safety. Instead of throwing exception we can write a record to the file.
                if(_inTransit!=null)
                {
                    throw new IllegalActionException("two airplanes in one track");
                }
                
                Token inputAircraft=input.get(i);
                _counter++;
                _delayOfEachAirplanes=0.0;
                // Write to file.
                _valuesForFile[0]=_id;
                _valuesForFile[1]=((RecordToken)inputAircraft).get("aircraftId");
                _setIcon(((IntToken)_valuesForFile[1]).intValue());
                _valuesForFile[2]=new DoubleToken(currentTime.getDoubleValue());
                _valuesForFile[3]=new IntToken(_counter);
                _valuesForFile[4]=new DoubleToken(_delayOfEachAirplanes);
                _writeToFile=new RecordToken(_lablesOfFile,_valuesForFile);
//                _writingToFile((Token)_writeToFile);
//                // End of writing to file.
                
                // Remove booking for this track.
                ((AbstractATCDirector)_director).removeBooking(_id);
                
                RecordToken aircraftWithInformation=((AbstractATCDirector)_director).routing(inputAircraft, _id);
                
                // Time of reaching to the next track.
                _arriveInTime=currentTime.add(((DoubleToken)aircraftWithInformation.get("delay")).doubleValue());
                
                // Expire t time (_predictionTime) before reaching to the next track.
                _transitExpires = currentTime.add(((DoubleToken)aircraftWithInformation.get("delay")).doubleValue()-((AbstractATCDirector)_director).getPredictionTime());
                
                _OutRoute=((IntToken)aircraftWithInformation.get("route")).intValue();
                _delayOfEachAirplanes+=((DoubleToken)aircraftWithInformation.get("delay")).doubleValue() - ((AbstractATCDirector)_director).getPredictionTime();
                
                ((AbstractATCDirector)_director).setInTransitStatusOfTrack(_id, _arriveInTime.getDoubleValue());
             //   ((ATCDirector)_director).setInTransitStatusOfTrackForRerout(_id, true);
                
               // Creating a new aircraft to sent to output from aircraftWighInformation.
                Map<String, Token> newAircraft=new TreeMap<String, Token>();
                newAircraft.put("aircraftId", aircraftWithInformation.get("aircraftId"));
                newAircraft.put("aircraftSpeed", aircraftWithInformation.get("aircraftSpeed"));
                newAircraft.put("flightMap", aircraftWithInformation.get("flightMap"));
                newAircraft.put("priorTrack", aircraftWithInformation.get("priorTrack"));
               // Change the fuel. 
                double fuel=((DoubleToken)aircraftWithInformation.get("fuel")).doubleValue();
                fuel=fuel-((AbstractATCDirector)_director).calculateFuelConsumption(((DoubleToken)aircraftWithInformation.get("delay")).doubleValue()-((AbstractATCDirector)_director).getPredictionTime()
                        ,((DoubleToken)aircraftWithInformation.get("aircraftSpeed")).doubleValue());
                newAircraft.put("fuel",(Token)(new DoubleToken(fuel)));
                //End of changing the fuel.
                newAircraft.put("arrivalTimeToAirport", aircraftWithInformation.get("arrivalTimeToAirport"));
                newAircraft.put("dipartureTimeFromAirport", aircraftWithInformation.get("dipartureTimeFromAirport"));
                //End of creating a new aircraft.
                
                //Store information in ATCDirector to decide about accepting or rejecting in next Track.
                ((AbstractATCDirector)_director).storeInformation(aircraftWithInformation.get("flightMap"),aircraftWithInformation.get("priorTrack")
                        ,fuel,_arriveInTime);
                _inTransit=(Token) (new RecordToken(newAircraft));
                _director.fireAt(this, _transitExpires);

            }
    }

    @Override
    public void initialize() throws IllegalActionException {
        super.initialize();
        _director=getDirector();
        _inTransit = null;
        _OutRoute=-1;
        _id=trackId.getToken();
        _isStormy=stormy.getToken();
        ArrayToken neigh=(ArrayToken)neighbors.getToken();
       ((AbstractATCDirector)_director).handleInitializedTrack(_id,_isStormy,neigh);
       _called=false;
       _counter=0;
       _delayOfEachAirplanes=0.0;
       _setIcon(-1);
       _acceptedId=-1;
       _selectedAircraft=false;
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         protected methods                 ////
    
    /** Update fuel of the aircraft based on the duration of the flight.
     * @param _inTransit2 The record contains information of the aircraft.
     * @param delay The duration of the flight.
     * @return The record contains new information of the aircraft.
     * @throws IllegalActionException
     */
    protected Token _changingFuel(Token _inTransit2, double delay) throws IllegalActionException {
        RecordToken temp=(RecordToken)_inTransit2;
        double fuel=((DoubleToken)temp.get("fuel")).doubleValue();
//        if(fuel<=0)
//            throw new IllegalActionException("Fuel can not be negative or zero for airplane "+((IntToken)temp.get("aircraftId")).intValue());
        fuel=fuel- ((AbstractATCDirector)_director).calculateFuelConsumption(delay , ((DoubleToken)temp.get("aircraftSpeed")).doubleValue());
        Map<String, Token> newAircraft=new TreeMap<String, Token>();
        newAircraft.put("aircraftId", temp.get("aircraftId"));
        newAircraft.put("aircraftSpeed", temp.get("aircraftSpeed"));
        newAircraft.put("flightMap", temp.get("flightMap"));
        newAircraft.put("priorTrack", temp.get("priorTrack"));
        newAircraft.put("fuel",(Token)(new DoubleToken(fuel)));
        newAircraft.put("arrivalTimeToAirport", temp.get("arrivalTimeToAirport"));
        newAircraft.put("dipartureTimeFromAirport", temp.get("dipartureTimeFromAirport"));
        return ((Token) (new RecordToken(newAircraft)));
    }

    /** Set the visual indication of the icon for the specified ID.
     *  @param id The aircraft ID or -1 to indicate no aircraft.
     *  @throws IllegalActionException
     */
    protected void _setIcon(int id) throws IllegalActionException {
        ArrayToken color = _noAircraftColor;
        if(id>-1){
            color = ((AbstractATCDirector)_director).handleAirplaneColor(id);
        }
        _shape.fillColor.setToken(color);
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         public variables               ////
    
    // Shape variables.
    public ResizablePolygonAttribute _shape;
    public EllipseAttribute _circle;
    /** Time of reaching to the end of this track. */
    public Time _arriveInTime;
    public int _acceptedId;
    public int _counter;
    public boolean _called;
    public double _delayOfEachAirplanes;
    public Token _inTransit;
    public Token _isStormy;
    public boolean _selectedAircraft;
    public int _OutRoute;
    /** A time in middle of the flight to see the situation of the next track. 
     * At this time director decide about this aircraft.
     * The next track may be booked for this aircraft or the aircraft is rerouted.
     */
    public Time _transitExpires;
    
    ///////////////////////////////////////////////////////////////////
    ////                         private variables               ////

    private DoubleToken _one = new DoubleToken(1.0);
    private Token[] _white = {_one, _one, _one, _one};
    private ArrayToken _noAircraftColor = new ArrayToken(_white);
    private Director _director;
    private Token _id;
    private String[] _lablesOfFile={"trackId","aircraftId","currentTime","trackLoad","delayOfaircraft"};
    private String[] _lables={"aircraftId","aircraftSpeed","flightMap","priorTrack","fuel","arrivalTimeToAirport","dipartureTimeFromAirport"};
    private Type[] _types={BaseType.INT,BaseType.DOUBLE,new ArrayType(BaseType.INT),BaseType.INT,BaseType.DOUBLE,BaseType.DOUBLE,BaseType.DOUBLE};
    private Token[] _valuesForFile={null,null,null,null,null};
    private RecordToken _writeToFile;
}
