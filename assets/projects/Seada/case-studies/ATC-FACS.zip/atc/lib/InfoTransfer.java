/* A model of a information transferring actor in air traffic control systems.
 
 Copyright (c) 2015 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY

 */
package ptolemy.domains.atc.lib;


import java.util.Map;
import java.util.TreeMap;

import ptolemy.actor.Director;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;
import ptolemy.actor.util.Time;
import ptolemy.data.DoubleToken;
import ptolemy.data.IntToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.ArrayType;
import ptolemy.data.type.BaseType;
import ptolemy.data.type.RecordType;
import ptolemy.data.type.Type;
import ptolemy.domains.atc.kernel.AbstractATCDirector;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Attribute;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;
///////////////////////////////////////////////////////////////////
////InfoTransformer
/** This actor is used to calculate and also transfer the results of performance prediction to the ATCDirector.
 *  @author Maryam Bagheri.
 */
public class InfoTransfer extends TypedAtomicActor{

    public InfoTransfer(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
        
        input = new TypedIOPort(this, "input", true, false);
        input.setMultiport(true);
        input.setTypeEquals(new RecordType(_lables, _types));
        
        output = new TypedIOPort(this, "Output", false, true);
        output.setTypeEquals(BaseType.RECORD); 
        
//        numOfArrivedAicraft = new TypedIOPort(this, "numOfArrivedAicraft", false, true);
//        numOfArrivedAicraft.setTypeEquals(BaseType.INT);
//        StringAttribute cardinality = new StringAttribute(numOfArrivedAicraft, "_cardinal");
//        cardinality.setExpression("NORTH");
//
//        flightDuration=new TypedIOPort(this,"flightDuration",false,true);
//        flightDuration.setTypeEquals(BaseType.DOUBLE);
//        
//        delayInAirport=new TypedIOPort(this,"delayInAirport",false,true);
//        delayInAirport.setTypeEquals(BaseType.DOUBLE);
        
//        timeOfLastArrival=new TypedIOPort(this,"timeOfLastArrival",false,true);
//        timeOfLastArrival.setTypeEquals(BaseType.DOUBLE);
//        cardinality = new StringAttribute(timeOfLastArrival, "_cardinal");
//        cardinality.setExpression("SOUTH");
        
        delay= new Parameter(this, "modelExecutionTime");
        delay.setTypeEquals(BaseType.DOUBLE);
        
        aircraftNum=new Parameter(this, "aircraftNumber");
        aircraftNum.setTypeEquals(BaseType.INT);
        aircraftNum.setExpression("100");
        
        iterationId=new Parameter(this, "iterationId");
        iterationId.setTypeEquals(BaseType.INT);
        iterationId.setExpression("-1");
       
        
    }
    ///////////////////////////////////////////////////////////////////
    ////                       ports and parameters                //// 
    public TypedIOPort input, output; 
//    numOfArrivedAicraft, flightDuration, delayInAirport, timeOfLastArrival;
    public Parameter delay, aircraftNum, iterationId;
    
    ///////////////////////////////////////////////////////////////////
    ////                         public methods                    ////
    
    @Override
    public void attributeChanged(Attribute attribute) throws IllegalActionException {
        if(attribute==iterationId)
            _itID=iterationId.getToken();
    }
    
    @Override
    public void fire() throws IllegalActionException {
        super.fire();
        Time currentTime=_director.getModelTime();
        if(currentTime.equals(_transitExpires)){
            int temp=((AbstractATCDirector)_director).numberOfRerouting();
            if(_numberOfPrediction!=temp && ((AbstractATCDirector)_director).is_doPrediction() && _inPrediction==false ){
                _inPrediction=true;
                _numberOfPrediction=temp;
            }

            if(_inPrediction==false)
            { 
                Map<String, Token> info=new TreeMap<String, Token>();
//              info.put("NumberOfStorm", new IntToken(_numberOfStorm));
                _bInAir=((AbstractATCDirector)_director).getNumberOfBlocked();
                _bInAirport=((IntToken)aircraftNum.getToken()).intValue()-_bInAir-_count;
//                if(true)
//                    throw new IllegalActionException("count "+_count+" bair "+_bInAir+" binair "+_bInAirport);
              info.put("NOfArrived",new IntToken(_count));
              info.put("BlockedInAir", new IntToken(_bInAir));
              info.put("BlockedInAirport", new IntToken(_bInAirport));
              info.put("AverageFlightD", new DoubleToken(_fDuration/_count));
              info.put("AverageDelayInAirport", new DoubleToken(_dInAirport/_count));
              info.put("TimeOfLastA", new DoubleToken(_lastFlightTime));
              info.put("iterationId", _itID);
              Token param=(Token) new RecordToken(info);
              ((AbstractATCDirector)_director).clearATCDirector(); 
              output.send(0, param);
//              if(true)
//                  throw new IllegalActionException("hey");
            }
           if(_inPrediction==true){
               _bInAir=((AbstractATCDirector)_director).getNumberOfBlocked();
               _bInAirport=((IntToken)aircraftNum.getToken()).intValue()-_bInAir-_count;
               ((AbstractATCDirector)_director).makeDecision(_count, _bInAir, _bInAirport,((IntToken)aircraftNum.getToken()).intValue(),_fDuration,_dInAirport,_lastFlightTime);
               _count=_tempCount;
               _fDuration=_tempFDuration;
               _dInAirport=_tempDInAirport;
               _lastFlightTime=_tempLastFlightTime;
               _inPrediction=false;
           }
           return;
        }
        for(int i=0; i< input.getWidth();i++){
            if(input.hasNewToken(i)){
               if(((AbstractATCDirector)_director).is_doPrediction() && _inPrediction==false)
               {
                   _inPrediction=true;
                   // Make a copy of each variable.
                   _tempCount=_count;
                   _tempFDuration=_fDuration;
                   _tempDInAirport=_dInAirport;
                   _tempLastFlightTime=_lastFlightTime;
                   _numberOfPrediction++;
                   
               }
               _count++;
               RecordToken airplane=(RecordToken)input.get(i);
               _fDuration+=currentTime.getDoubleValue()-((DoubleToken)airplane.get("dipartureTimeFromAirport")).doubleValue();
               _dInAirport+=((DoubleToken)airplane.get("dipartureTimeFromAirport")).doubleValue()-((DoubleToken)airplane.get("arrivalTimeToAirport")).doubleValue();
               _lastFlightTime=currentTime.getDoubleValue();
            }
        }
    }
    
    @Override
    public void initialize() throws IllegalActionException {
        super.initialize();
        _count=0;
        if(delay.getToken()==null || ((DoubleToken)delay.getToken()).doubleValue()==0.0)
            throw new IllegalActionException(" The model execution time can not be null or zero");
        
        _director=getDirector();
        _transitExpires=_director.getModelTime().add(((DoubleToken)delay.getToken()).doubleValue());
        _director.fireAt(this, _transitExpires);
        _fDuration=0.0;
        _dInAirport=0.0;
        _lastFlightTime=0.0;
        _inPrediction=false;
        _bInAir=0;
        _bInAirport=0;
        _itID=iterationId.getToken();
        _numberOfPrediction=0;
    }
    
    ///////////////////////////////////////////////////////////////////
    ////                         private variables               ////
    private boolean _inPrediction;
    private int _numberOfPrediction;
    private Token _itID;
    private int _bInAirport;
    private int _bInAir;
    private int _count;
    private int _tempCount;
    private Director _director;
    private Time _transitExpires;
    private double _fDuration;
    private double _tempFDuration;
    private double _dInAirport;
    private double _tempDInAirport;
    private double _lastFlightTime;
    private double _tempLastFlightTime;
    private String[] _lables={"aircraftId","aircraftSpeed","flightMap","priorTrack","fuel","arrivalTimeToAirport","dipartureTimeFromAirport"};
    private Type[] _types={BaseType.INT,BaseType.DOUBLE,new ArrayType(BaseType.INT),BaseType.INT,BaseType.DOUBLE,BaseType.DOUBLE,BaseType.DOUBLE};

}
