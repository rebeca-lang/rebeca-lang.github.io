/* A composite actor that create a clone of itself in middle of the execution
 *  and executes sub model of the new created actor in fire().

 Copyright (c) 1998-2014 The Regents of the University of California.
 All rights reserved.
 Permission is hereby granted, without written agreement and without
 license or royalty fees, to use, copy, modify, and distribute this
 software and its documentation for any purpose, provided that the above
 copyright notice and the following two paragraphs appear in all copies
 of this software.

 IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
 ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
 THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
 PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
 ENHANCEMENTS, OR MODIFICATIONS.

 PT_COPYRIGHT_VERSION_2
 COPYRIGHTENDKEY
 */
package ptolemy.domains.atc.lib;

import java.util.Iterator;
import java.util.List;
import ptolemy.actor.Director;
import ptolemy.actor.TypedCompositeActor;
import ptolemy.actor.TypedIOPort;
import ptolemy.actor.TypedIORelation;
import ptolemy.actor.lib.hoc.LifeCycleManager;
import ptolemy.domains.atc.kernel.ATCAnalyzerDirector;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.Attribute;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.InternalErrorException;
import ptolemy.kernel.util.KernelException;
import ptolemy.kernel.util.NameDuplicationException;
import ptolemy.kernel.util.Workspace;

///////////////////////////////////////////////////////////////////
////ATCCompositeActor
/**
 * ATCCompositeActor is a composite actor with mixed behavior of the CompositeActor and RunCompositeActor. 
 * This actor is used in ATC model with aim of performance prediction. 
 * ATCCompositeActor acts like a CompositeActor until a change happens in the sub-model. 
 * By occurring a change, it generates a clone of itself in middle of the execution 
 * (The values of the all clone variables are same as the master ones in middle of the execution) 
 * and set its flag ,_isMaster, to false. This flag shows that the generated actor in not the main one 
 * and has to be removed after the performance predication.
 * After creation, the new created actor is connected to the model 
 * and the master actor informs its executive director (ATCAnalyzerDirector) 
 * to put a triggering event for the created actor at the first of the _eventQueue. 
 * So the clone has higher priority rather than the master one and it will execute 
 * inside model atomically in the fire method exactly same as the RunCompositeActor. 
 * To write this actor, some parts of the code has been copied from the MultiInstanceComposite.
 * @author Maryam Bagheri
 */
public class ATCCompositeActor extends LifeCycleManager {
    /** Construct an actor in the default workspace with no
     *  container and an empty string as its name. Add the actor to the
     *  workspace directory.  You should set the local director or
     *  executive director before attempting to send data to the actor or
     *  to execute it. Increment the version number of the workspace.
     */
    public ATCCompositeActor() {
        super();
    }

    /** Construct a ATCCompositeActor in the specified workspace with
     *  no container and an empty string as a name. You can then change
     *  the name with setName(). If the workspace argument is null, then
     *  use the default workspace.  You should set the local director or
     *  executive director before attempting to send data to the actor
     *  or to execute it. Add the actor to the workspace directory.
     *  Increment the version number of the workspace.
     *  @param workspace The workspace that will list the actor.
     */
    public ATCCompositeActor(Workspace workspace) {
        super(workspace);
    }

    /** Construct a ATCCompositeActor with a name and a container.
     *  The container argument must not be null, or a
     *  NullPointerException will be thrown.  This actor will use the
     *  workspace of the container for synchronization and version counts.
     *  If the name argument is null, then the name is set to the empty string.
     *  Increment the version of the workspace.  This actor will have no
     *  local director initially, and its executive director will be simply
     *  the director of the container.
     *
     *  @param container The container.
     *  @param name The name of this actor.
     *  @exception IllegalActionException If the container is incompatible
     *   with this actor.
     *  @exception NameDuplicationException If the name coincides with
     *   an actor already in the container.
     */
    public ATCCompositeActor(CompositeEntity container, String name)
            throws IllegalActionException, NameDuplicationException {
        super(container, name);
    }
    
    /** ATCDirector calls this method by occureing the storm. 
     * This method creates a clone and requests its executive director to enqueue a triggering event 
     * to the _eventQueue.
     * Container of the created clone is set and it is connected to the same input/output ports of the master. 
     */
    public void changeHandling() throws IllegalActionException {
       
        TypedCompositeActor container=(TypedCompositeActor) getContainer();
        ATCCompositeActor newObject=null;
        try {
            newObject=(ATCCompositeActor)_cloneClone(container.workspace());
        } 
        catch (CloneNotSupportedException ex) {
            throw new IllegalActionException(this, ex, "Clone failed.");
        }
        
        _linkClone(newObject);
        
        ATCAnalyzerDirector executiveDirector=(ATCAnalyzerDirector) container.getExecutiveDirector();
        executiveDirector.enqueuePredictionEvent(newObject);
    }
    
    @Override
    public Object clone(Workspace workspace) throws CloneNotSupportedException {
        ATCCompositeActor newObject = (ATCCompositeActor) super.clone(workspace);
        newObject._isMaster=true;
        return newObject;
    }
    
    //SUPER.CLONE, ATCDirector.clone, Track.clone, Airport.clone, DestinationAirport.clone.
    /* FIXME: I have problem with super.clone(), 
     * because we need clone of the actors with the mid-execution variables.(non-Javadoc).
     * @see ptolemy.actor.CompositeActor#clone(ptolemy.kernel.util.Workspace)
     */
    /**
     * Clone to create a copy of the master with mid-execuation variables.
     * @param workspace
     * @return ATCCompositeActor object.
     * @throws CloneNotSupportedException
     */
    private Object _cloneClone(Workspace workspace)
            throws CloneNotSupportedException {
        ATCCompositeActor newObject = (ATCCompositeActor) super
                .clone(workspace);
        newObject._isMaster = false;
        // The following is necessary in case an exception occurs
        // during execution because then wrapup might not properly complete.
        newObject.setPersistent(false);

        return newObject;
    }

    /* _executeInsideModel has been copies from RunCompositeActor.
     * But some places has been changed or commented annotated by "Maryam".
     */
    /** Run a complete execution of the contained model.  A complete
     *  execution consists of invocation of super.initialize(), repeated
     *  invocations of super.prefire(), super.fire(), and super.postfire(),
     *  followed by super.wrapup().  The invocations of prefire(), fire(),
     *  and postfire() are repeated until either the model indicates it
     *  is not ready to execute (prefire() returns false), or it requests
     *  a stop (postfire() returns false or stop() is called).
     *  @exception IllegalActionException If there is no director, or if
     *   the director's action methods throw it.
     *  @return One of COMPLETED, STOP_ITERATING, or NOT_READY to
     *   indicate that either the execution completed or stop
     *   was externally requested, stopped because
     *   postfire() returned false, or stopped because prefire() returned
     *   false, respectively.
     */ 
    protected int _executeInsideModel() throws IllegalActionException {
        try {
            // Make sure that change requests are not executed when requested,
            // but rather only executed when executeChangeRequests() is called.
            setDeferringChangeRequests(true);

            Director insideDirector = getDirector();
            Director outsideDirector = getExecutiveDirector();
            if (insideDirector == outsideDirector) {
                throw new IllegalActionException(this,
                        "An inside director is required to execute the inside model.");
            }
            // Force the inside director to behave as if it were at the top level.
            insideDirector.setEmbedded(false);
            // Maryam.
            // _readInputs();

            if (_stopRequested) {
                return COMPLETED;
            }

            // FIXME: Reset time to zero. How?
            // NOTE: Use the superclass initialize() because this method overrides
            // initialize() and does not initialize the model.
            
            // Maryam.
            // super.initialize();

            // Call iterate() until finish() is called or postfire()
            // returns false.
            _debug("-- Beginning to iterate.");

            int lastIterateResult = COMPLETED;

            while (!_stopRequested) {
                executeChangeRequests();

                if (super.prefire()) {
                    // Cannot use super.fire() here because it does
                    // some inappropriate things like reading port parameters
                    // and transferring inputs.
                    _fireInsideModel();

                    if (!super.postfire()) {
                        lastIterateResult = STOP_ITERATING;
                        break;
                    }
                } else {
                    lastIterateResult = NOT_READY;
                    break;
                }
            }

            return lastIterateResult;
        } finally {
            try {
                executeChangeRequests();
                super.wrapup();
            } finally {
                // Indicate that it is now safe to execute
                // change requests when they are requested.
                setDeferringChangeRequests(false);
                
                // Added by Maryam.
                _removeClone();
                TypedCompositeActor container=(TypedCompositeActor) getContainer();
                ATCAnalyzerDirector executiveDirector=(ATCAnalyzerDirector) container.getExecutiveDirector();
                executiveDirector.enqueueDeferedEvents();  
            }
            // Maryam.
            // if (!_stopRequested) {
            // _writeOutputs();
            // }

            if (_debugging) {
                _debug("---- Firing is complete.");
            }
        }
    }
    
    /** If the current composite actor is not the master one,
     *  it will be fired as the RunCompositeActor else fired like the CompositeActor.(non-Javadoc)
     * @see ptolemy.actor.CompositeActor#fire()
     */
    @Override
    public void fire() throws IllegalActionException {
        if(_isMaster==false)
            _executeInsideModel();
        else
            super.fire();
    }
    
    /** This method is used to link the created clone to the input
     * and outpot ports of the master actor. Code of this method has been copied
     * from MultiInstanceCompositeActor. Some places has been annotated by "Maryam"
     * @param object.
     * @throws IllegalActionException
     */
    private void _linkClone(ATCCompositeActor object) throws IllegalActionException{
        
        TypedCompositeActor container = (TypedCompositeActor) getContainer();
        try {
            _workspace.getWriteAccess();
         // Hide the clone.
            try {
                new Attribute(object, "_hide");
            } catch (KernelException e) {
                // This should not occur.  Ignore if it does
                // since the only downside is that the actor is
                // rendered.
            }
            try{
                object.setContainer(container);
                object.validateSettables();
                if (_debugging) {
                    _debug("Cloned: " + object.getFullName());
                }
             // Clone all attached relations and link to same
                // ports as the originals
                Iterator<?> ports = portList().iterator();

                while (ports.hasNext()) {
                    TypedIOPort port = (TypedIOPort) ports.next();
                    TypedIOPort newPort = (TypedIOPort) object.getPort(port.getName());
                    List<?> relations = port.linkedRelationList();
                    if (relations == null || relations.size() < 1) {
                        continue;
                    }
                    if (relations.size() > 1) {
                        throw new IllegalActionException(port,
                                "Can be linked to one relation only");
                    }

                    TypedIORelation relation = (TypedIORelation) relations
                            .get(0);
                    TypedIORelation oldRelation = relation;

                    // Iterate through other ports that are connected to this port.
                    // If a connected port is a multiport, then we create
                    // a new relation to connect the clone's newPort
                    // to that multiport. Otherwise, we use the
                    // relation above to link newPort.
                    Iterator<?> otherPorts = relation.linkedPortList(port)
                            .iterator();

                    // Added by Gang Zhou. If a port is connected to
                    // multiple other ports (through a single relation),
                    // only one relation should be created.
                    boolean isRelationCreated = false;
                    boolean isPortLinked = false;

                    while (otherPorts.hasNext()) {
                        TypedIOPort otherPort = (TypedIOPort) otherPorts
                                .next();

                        if (port.isOutput() && !otherPort.isMultiport()) {
                            throw new IllegalActionException(
                                    this,
                                    getFullName()
                                    + ".preinitialize(): "
                                    + "output port "
                                    + port.getName()
                                    + "must be connected to a multi-port");
                        }

                        // Modified by Gang Zhou so that the port can
                        // be connected to the otherPort either from inside
                        // or from outside.
                        boolean isInsideLinked = otherPort
                                .isInsideGroupLinked(oldRelation);

                        if (port.isInput()
                                && (!isInsideLinked && otherPort.isOutput() || isInsideLinked
                                        && otherPort.isInput())
                                        || port.isOutput()
                                        && (!isInsideLinked && otherPort.isInput() || isInsideLinked
                                                && otherPort.isOutput())) {
                            if (otherPort.isMultiport()) {
                                if (!isRelationCreated) {
                                    relation = new TypedIORelation(
                                            container, "r_" + getName()
                                            + "_" + port.getName());
                                    relation.setPersistent(false);
                                    isRelationCreated = true;

                                    if (_debugging) {
                                        _debug(port.getFullName()
                                                + ": created relation "
                                                + relation.getFullName());
                                    }
                                }

                                otherPort.link(relation);
                            }

                            if (!isPortLinked) {
                                newPort.link(relation);
                                isPortLinked = true;

                                if (_debugging) {
                                    _debug(newPort.getFullName()
                                            + ": linked to "
                                            + relation.getFullName());
                                }
                            }
                        }
                    }
                }
            }
            catch (NameDuplicationException ex)
            {
                throw new IllegalActionException(this, ex,
                        "couldn't clone/create");
            }
        }
        finally{
            _workspace.doneWriting();
        }
        
        // Added by Maryam.
        Director executiveDirector = getExecutiveDirector();
        if(executiveDirector!=null)
        {
            executiveDirector.invalidateSchedule();
        }
    }
    
    /** This method is used to removed the created clone from model. Code of this method has been copied
     * from MultiInstanceCompositeActor. Some places has been annotated by "Maryam".
     * @throws IllegalActionException
     */
    private void _removeClone() throws IllegalActionException{
        try {
              _workspace.getWriteAccess();
            Iterator<?> ports = portList().iterator();
            while (ports.hasNext()) {
                TypedIOPort port = (TypedIOPort) ports.next();
                Iterator<?> relations = port.linkedRelationList()
                        .iterator();
                while (relations.hasNext()) {
                    TypedIORelation relation = (TypedIORelation) relations
                            .next();
    
                    // Use a different criterion to delete relation
                    // since the old one wouldn't work any more.
                    // Added by Gang Zhou.
                    TypedIOPort mirrorPort = (TypedIOPort) getPort(port
                            .getName());
    
                    if (!port.isDeeplyConnected(mirrorPort)) {
                        //if (relation.linkedPortList().size() <= 2) {
                        // Delete the relation that was created in
                        // preinitialize()
                        try {
                            if (_debugging) {
                                _debug("Deleting " + relation.getFullName());
                            }
                            relation.setContainer(null);
                        } catch (NameDuplicationException ex) {
                            throw new InternalErrorException(ex);
                        }
                    } else {
                        // Unlink the clone's port from the relation
                        if (_debugging) {
                            _debug("Unlinking " + port.getFullName()
                                    + " from " + relation.getFullName());
                        }
                        port.unlink(relation);
                    }
                }
            }
         // Now delete the clone itself
            try {
                if (_debugging) {
                    _debug("Deleting " + getFullName());
                }
                setContainer(null);
            } catch (NameDuplicationException ex) {
                throw new InternalErrorException(ex);
            }
        }
        finally {
            _workspace.doneWriting();
        }
     
        // Added by Maryam
        Director executiveDirector = getExecutiveDirector();
        if(executiveDirector!=null)
        {
            executiveDirector.invalidateSchedule();
        }
   }
    
    
    ///////////////////////////////////////////////////////////////////
    ////                         private variables                 ////
    /** If the current ATCCompositeActor is master the value is true otherwise it is clone.
     */
    private boolean _isMaster = true;

}
