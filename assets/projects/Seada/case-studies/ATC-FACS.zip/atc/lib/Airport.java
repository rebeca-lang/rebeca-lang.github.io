/* A model of a source airport in air traffic control systems.

Copyright (c) 2015 The Regents of the University of California.
All rights reserved.
Permission is hereby granted, without written agreement and without
license or royalty fees, to use, copy, modify, and distribute this
software and its documentation for any purpose, provided that the above
copyright notice and the following two paragraphs appear in all copies
of this software.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.

THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE
PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
ENHANCEMENTS, OR MODIFICATIONS.

PT_COPYRIGHT_VERSION_2
COPYRIGHTENDKEY

*/
package ptolemy.domains.atc.lib;

import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;



import ptolemy.actor.Director;
import ptolemy.actor.NoRoomException;
import ptolemy.actor.TypedAtomicActor;
import ptolemy.actor.TypedIOPort;
import ptolemy.actor.util.Time;
import ptolemy.data.ArrayToken;
import ptolemy.data.DoubleToken;
import ptolemy.data.IntToken;
import ptolemy.data.RecordToken;
import ptolemy.data.Token;
import ptolemy.data.expr.Parameter;
import ptolemy.data.type.ArrayType;
import ptolemy.data.type.BaseType;
import ptolemy.domains.atc.kernel.AbstractATCDirector;
import ptolemy.kernel.CompositeEntity;
import ptolemy.kernel.util.IllegalActionException;
import ptolemy.kernel.util.NameDuplicationException;

///////////////////////////////////////////////////////////////////
////Airport
/** This actor receives a record token which shows an aircraft decides to fly.
 * Therefore, this actor just sends that token to a proper direction based on its neighbors. 
 * If the destination track (first track in the aircraft's flight map) is unavailable,
 * then airport tries to send it after a period of time. 
 * Sometime, ATCDirector decides to decrease load of the airspace and does not let to airport
 * to send out an aircraft.
 *  @author Maryam Bagheri.
*/
public class Airport extends TypedAtomicActor{ 

   public Airport(CompositeEntity container, String name)
           throws IllegalActionException, NameDuplicationException {
       super(container, name);
       
       input = new TypedIOPort(this, "input", true, false);
       input.setTypeEquals(BaseType.RECORD);
               
       Output = new TypedIOPort(this, "Output", false, true);
       Output.setTypeEquals(BaseType.RECORD);
       Output.setMultiport(true);
       
       delay= new Parameter(this, "delay");
       delay.setTypeEquals(BaseType.DOUBLE);
       delay.setExpression("1");
       
       takeOff= new Parameter(this, "takeOff");
       takeOff.setTypeEquals(BaseType.DOUBLE);
       takeOff.setExpression("1");
       
       airportId= new Parameter(this, "airportId");
       airportId.setTypeEquals(BaseType.INT);
       airportId.setExpression("-1");
       
       connectedTracks = new Parameter(this, "connectedTracks");
       connectedTracks.setExpression("{}");
       connectedTracks.setTypeEquals(new ArrayType(BaseType.INT));
   }
   
    ///////////////////////////////////////////////////////////////////
    ////                       ports and parameters                ////
   public TypedIOPort input;
   public TypedIOPort Output;
   public Parameter connectedTracks, delay,airportId,takeOff;
   
    ///////////////////////////////////////////////////////////////////
    ////                         public methods                    ////
   
   @Override
   public void fire() throws IllegalActionException {
       super.fire();
       Time currentTime = _director.getModelTime();
//       if(((AbstractATCDirector)_director).numberOfRerouting()==1 && ((AbstractATCDirector)_director).is_doPrediction()==false)
//           throw new IllegalActionException("transitExipire: "+ _transitExpires+" currentTIme: "+currentTime);
       if (currentTime.equals(_transitExpires) && _inTransit!=null ) {
          
           // Check the ATCDirector permission to take off. Maybe the airspace is
           // globally congested and load of the airspace should be decreased.
           if(((AbstractATCDirector)_director).getPermission()){ 
               // Does not allow.
               double additionalDelay = ((DoubleToken)delay.getToken()).doubleValue();
               if (additionalDelay < 0.0) {
                   throw new IllegalActionException(this, "Unable to handle waiting.");
               }
               _transitExpires = _transitExpires.add(additionalDelay);
               _director.fireAt(this, _transitExpires);
           }
           else{
               
               try{
                  
                 // When airport decides to send out an airplane it must set it's departure time.
                 // For this purpose, we make a new RecordToken.
                  double departureTime=currentTime.getDoubleValue()-((DoubleToken)takeOff.getToken()).doubleValue();
                   RecordToken firstAirplane=_airplanes.get(0);
                   Map<String, Token> tempAircraft=new TreeMap<String, Token>();
                   tempAircraft.put("aircraftId", firstAirplane.get("aircraftId"));
                   tempAircraft.put("aircraftSpeed", firstAirplane.get("aircraftSpeed"));
                   tempAircraft.put("flightMap", firstAirplane.get("flightMap"));
                   tempAircraft.put("fuel", firstAirplane.get("fuel"));
                   tempAircraft.put("priorTrack", firstAirplane.get("priorTrack"));
                   tempAircraft.put("arrivalTimeToAirport",firstAirplane.get("arrivalTimeToAirport"));
                   tempAircraft.put("dipartureTimeFromAirport", new DoubleToken(departureTime));
                   _airplanes.set(0, new RecordToken(tempAircraft));
                   
                   int i=_findDirection(_airplanes.get(0));
                 //This part has been written instead of _findDirection function for backtracking.
//                   RecordToken airplane=_airplanes.get(0);
//                   ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
//                   int i=-1;
//                   for(int j=0; j<_Tracks.length();j++)
//                       if(flightMap.getElement(0).equals(_Tracks.getElement(j))){
//                           i=j;
//                           break;
//                       }
//                   if(i==-1)
//                       throw new IllegalActionException("There is no route from the airport to the first track in flightMap");
                   Output.send(i, _airplanes.get(0));
                   _airplanes.remove(0);
                   _inTransit=null;
               } catch(NoRoomException ex){
                   
                  double additionalDelay = ((DoubleToken)delay.getToken()).doubleValue();
                   if (additionalDelay < 0.0) {
                       throw new IllegalActionException(this, "Unable to handle rejection.");
                   }
                   _transitExpires = _transitExpires.add(additionalDelay);
                   _director.fireAt(this, _transitExpires);
               }
              
               if(_inTransit==null &&  _airplanes.size()!=0){
                   _inTransit=_airplanes.get(0);
                   double additionalDelay = ((DoubleToken)takeOff.getToken()).doubleValue();
                   if (additionalDelay < 0.0) {
                       throw new IllegalActionException(this, "Unable to handle rejection.");
                   }
                   _transitExpires = _transitExpires.add(additionalDelay);
                   _director.fireAt(this, _transitExpires);
               }
           }
       }
           
       if(input.hasToken(0))
       { 
          RecordToken airplane=(RecordToken) input.get(0);
          Map<String, Token> Aircraft=new TreeMap<String, Token>();
          Aircraft.put("aircraftId", airplane.get("aircraftId"));
          Aircraft.put("aircraftSpeed", airplane.get("aircraftSpeed"));
          Aircraft.put("flightMap", airplane.get("flightMap"));
          Aircraft.put("priorTrack", airportId.getToken());
          // Change the fuel of the airplane. It is subtracted by the taking off time.
          double fuel=((DoubleToken)airplane.get("fuel")).doubleValue();
          if(fuel<=0)
              throw new IllegalActionException("Fuel can not be negative or zero");
          fuel=fuel-((AbstractATCDirector)_director).calculateFuelConsumption(((DoubleToken)takeOff.getToken()).doubleValue(),
                  ((DoubleToken)airplane.get("aircraftSpeed")).doubleValue());
          Aircraft.put("fuel", (Token)(new DoubleToken(fuel)));
          // End of changing fuel.
          double arrivalTime=currentTime.getDoubleValue();
          Aircraft.put("arrivalTimeToAirport",new DoubleToken(arrivalTime));
          Aircraft.put("dipartureTimeFromAirport", new DoubleToken(arrivalTime));
          _airplanes.add(new RecordToken(Aircraft));
          
          if(_inTransit==null)
          {
              double additionalDelay = ((DoubleToken)takeOff.getToken()).doubleValue();
              if (additionalDelay < 0.0) {
                  throw new IllegalActionException(this, "Delay is negative in airport.");
              }
              _inTransit=_airplanes.get(0);
              _transitExpires = currentTime.add(additionalDelay);
              _director.fireAt(this, _transitExpires);
          }
       }
   }
   
   @Override
   public void initialize() throws IllegalActionException {
       super.initialize();
       _director=getDirector();
       _id=airportId.getToken();
       ((AbstractATCDirector)_director).handleInitializedAirport(_id);
      _inTransit=null;
       _Tracks=(ArrayToken)connectedTracks.getToken();
       if(_Tracks.length()==0)
           throw new IllegalActionException("there is no connected track to the airport in the airport's parameters ");
       _airplanes=new ArrayList<RecordToken>();
       
   }
   
   ///////////////////////////////////////////////////////////////////
   ////                         private methods                 ////
   
   /** This function compares the first element of the aircraft's flight map with the neighbors of the airport
    * to find the direction that aircraft have to fly.
    * @param airplane
    * @return Index of the airport's neighbor which shows the flight direction.
    * @throws IllegalActionException
    */
   private int _findDirection(RecordToken airplane) throws IllegalActionException{
       ArrayToken flightMap=(ArrayToken)airplane.get("flightMap");
       boolean finded=false;
       for(int i=0; i<_Tracks.length();i++)
           if(flightMap.getElement(0).equals(_Tracks.getElement(i))){
               finded=true;
               return i;
           }
       if(finded==false)
           throw new IllegalActionException("There is no route from the airport to the first track in flightMap");
       return -1;
   }
   
   ///////////////////////////////////////////////////////////////////
   ////                         private variables               ////
   public ArrayList<RecordToken> _airplanes;
   public Director _director;
   public Token _inTransit;
   public Time _transitExpires;
   private ArrayToken _Tracks;
   private Token _id;
   
}
