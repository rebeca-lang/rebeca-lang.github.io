1-	Install Ptolemy II,
2-	Go to the directory of your installation, then ptolemy/domains,
3-	Replace the atc folder with our atc folder,
4-	Note that we have changed several parameters of the DE director from private/protected to public. 
	Therefore, replace the DEDirector.class (and .java) with the previous one,
5-	Invoke the vergil,
6-	After coming vergil up, go to the atc/demo and select a model. 


Do not hesitate to contact maryam.bagheri1989@gmail.com if you have any problem.

Good Luck,
Maryam Bagheri.




